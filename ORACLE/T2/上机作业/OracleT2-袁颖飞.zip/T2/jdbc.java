package com.dldw.Dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class jdbc {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			String url="jdbc:oracle:thin:@127.0.0.1:1521:orcl";
			 String username="sys as sysdba";
			 String passwoed="123456";
			 Connection conn =DriverManager.getConnection(url,username,passwoed);
			Statement st=conn.createStatement();
			String sql="select * from dept";
			ResultSet rs=st.executeQuery(sql);
			while (rs.next()) {
				System.out.println(rs.getInt("did")+"\t");
				
			}
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}

	}

}
