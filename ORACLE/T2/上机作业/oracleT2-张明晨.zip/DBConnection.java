﻿package com.orclT1.DB;

import java.sql.Connection;
import java.sql.DriverManager;

public class  DBConnection {
//	连接数据库地址
	static String url="jdbc:oracle:thin:@localhost:1521:orcl";
        static String user="scott";
        static String password="tiger";
	static Connection conn=null;
	public static Connection getConnection(){
		if(conn==null){
			try {
//				连接驱动
				Class.forName("driver");
//				链接的数据库 账号密码
				conn=DriverManager.getConnection(url, "user", "password");
				
				System.out.println(conn);
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return conn;
		
	}
	
  public static void main(String[] args) {
	DBConnection.getConnection();
}
	}
	
