/**
 * 
 */
package com.oracle.connection;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

/**
 * @project oracleconnection ��Ŀ����
 * @name OracleConnection ������   
 * @describe (��һ�仰�������������)
 * @author Chichi ����
 * @time 2018-3-14 ����8:29:57
 */
public class OracleConnection {
   private static String Driver="";   //���ݿ�����
   private static String url="";      //���ݿ��ַ
   private static String name="";     //�û���
   private static String password=""; //����
   
   static{
	   start();
   };
   //�����ļ���ȡ����
   public static void start(){
	   InputStream resourceAsStream = OracleConnection.class.getResourceAsStream("/properties.properties");  
	   InputStreamReader reader =new InputStreamReader(resourceAsStream);
	   Properties ps=new Properties();
	   try {
		ps.load(reader);
		Driver=ps.getProperty("Driver");
		url=ps.getProperty("url");
		name=ps.getProperty("name");
		password=ps.getProperty("password");
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
   }
   
   //��ȡConnection����
   public static Connection conn(){
	  Connection conn=null;
	  try {
		Class.forName(Driver);
		conn= DriverManager.getConnection(url, name, password);
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}finally{
		if(conn!=null){
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}	
		}
	}
	  return conn;
   }
  
     public static void main(String[] args) {
    	 Connection conn = OracleConnection.conn();
    	 System.out.println(conn);
	}
}
