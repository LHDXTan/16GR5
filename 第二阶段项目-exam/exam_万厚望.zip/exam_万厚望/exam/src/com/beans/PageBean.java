package com.beans;

import java.util.ArrayList;
import java.util.List;

import com.pojo.Paper;
import com.pojo.Question;

public class PageBean {
public static void PageBean(){}
	private int pagesize;	//每页显示的数据条数
	private int pagetotal;	//总页数
	private int p;			//第p页
	private int count;		//数据总条数
	private List<Question> questionlist;
	private List<Paper> paperlist;
	
	
	public List<Paper> getPaperlist() {
		return paperlist;
	}
	public void setPaperlist(List<Paper> paperlist) {
		this.paperlist = paperlist;
	}
	public List<Question> getQuestionlist() {
		return questionlist;
	}
	public void setQuestionlist(List<Question> questionlist) {
		this.questionlist = questionlist;
	}
//	public PageBean(){
//		pagesize = 10;	//设置每页显示两条数据
//	}
	public int getPagesize() {
		return pagesize;
	}
	public void setPagesize(int pagesize) {
		this.pagesize = pagesize;
	}
	/**
	 * @return the pagetotal
	 */
	public int getPagetotal() {
		return pagetotal;
	}
	/**
	 * @return the p
	 */
	public int getP() {
		return p;
	}

	/**
	 * @param pagetotal the pagetotal to set
	 */
	public void setPagetotal(int pagetotal) {
		this.pagetotal = pagetotal;
	}
	/**
	 * @param p the p to set
	 */
	public void setP(int up) {
		if(up<1)p = 1;
		else p = up;
	}
	public void setCount(int count) {
		this.count = count;
		pagetotal = (int)Math.ceil(count*1.0/10);
	}
	public int getCount() {
		return count;
	}

}
