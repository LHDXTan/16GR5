package com.pojo;

/**
 * Student entity. @author MyEclipse Persistence Tools
 */

public class Student implements java.io.Serializable {

	// Fields

	private Integer sid;		//学生ID
	private Integer jid;		//角色
	private String sname;		//学生姓名
	private String loginuser;	//学号，登录名
	private String password;	//密码
	private String ssex;		//性别
	private String syear;		//入学年份
	private Integer sclass;		//所属班级
	private String sbirthday;	//生日
	private String sidcard;		//身份证号
	private String sphone;		//学生电话
	private Classes classes;
	

	// Constructors

	public Classes getClasses() {
		return classes;
	}

	public void setClasses(Classes classes) {
		this.classes = classes;
	}

	/** default constructor */
	public Student() {
	}

	/** minimal constructor */
	public Student(Integer sid, Integer jid, String sname, String loginuser,
			String password, String ssex, String syear, Integer sclass) {
		this.sid = sid;
		this.jid = jid;
		this.sname = sname;
		this.loginuser = loginuser;
		this.password = password;
		this.ssex = ssex;
		this.syear = syear;
		this.sclass = sclass;
	}

	/** full constructor */
	public Student(Integer sid, Integer jid, String sname, String loginuser,
			String password, String ssex, String syear, Integer sclass,
			String sbirthday, String sidcard, String sphone) {
		this.sid = sid;
		this.jid = jid;
		this.sname = sname;
		this.loginuser = loginuser;
		this.password = password;
		this.ssex = ssex;
		this.syear = syear;
		this.sclass = sclass;
		this.sbirthday = sbirthday;
		this.sidcard = sidcard;
		this.sphone = sphone;
	}

	// Property accessors

	public Integer getSid() {
		return this.sid;
	}

	public void setSid(Integer sid) {
		this.sid = sid;
	}

	public Integer getJid() {
		return this.jid;
	}

	public void setJid(Integer jid) {
		this.jid = jid;
	}

	public String getSname() {
		return this.sname;
	}

	public void setSname(String sname) {
		this.sname = sname;
	}

	public String getLoginuser() {
		return this.loginuser;
	}

	public void setLoginuser(String loginuser) {
		this.loginuser = loginuser;
	}

	public String getPassword() {
		return this.password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getSsex() {
		return this.ssex;
	}

	public void setSsex(String ssex) {
		this.ssex = ssex;
	}

	public String getSyear() {
		return this.syear;
	}

	public void setSyear(String syear) {
		this.syear = syear;
	}

	public Integer getSclass() {
		return this.sclass;
	}

	public void setSclass(Integer sclass) {
		this.sclass = sclass;
	}

	public String getSbirthday() {
		return this.sbirthday;
	}

	public void setSbirthday(String sbirthday) {
		this.sbirthday = sbirthday;
	}

	public String getSidcard() {
		return this.sidcard;
	}

	public void setSidcard(String sidcard) {
		this.sidcard = sidcard;
	}

	public String getSphone() {
		return this.sphone;
	}

	public void setSphone(String sphone) {
		this.sphone = sphone;
	}

}