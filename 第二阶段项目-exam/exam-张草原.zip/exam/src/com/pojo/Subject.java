package com.pojo;

import java.util.HashSet;
import java.util.Set;

/**
 * Subject entity. @author MyEclipse Persistence Tools
 */

public class Subject implements java.io.Serializable {

	// Fields
	//科目表
	private Integer suid;	//主键
	private String sudirec;	//专业方向
	private String sustage;	//专业阶段
	private String suName;	//科目名称
	transient private Set<Question> questions = new HashSet();
	private Integer pennub;		//笔试
	private Integer computernub;//机试
	
	
	
	

	// Constructors

	public Integer getPennub() {
		return pennub;
	}
	public void setPennub(Integer pennub) {
		this.pennub = pennub;
	}
	public Integer getComputernub() {
		return computernub;
	}
	public void setComputernub(Integer computernub) {
		this.computernub = computernub;
	}
	public Subject() {
	}
	/** full constructor */
	public Subject(Integer suid, String sudirec, String sustage, String suName) {
		this.suid = suid;
		this.sudirec = sudirec;
		this.sustage = sustage;
		this.suName = suName;
	}



	public Set<Question> getQuestions() {
		return questions;
	}



	public void setQuestions(Set<Question> questions) {
		this.questions = questions;
	}





	public Integer getSuid() {
		return suid;
	}



	public void setSuid(Integer suid) {
		this.suid = suid;
	}



	public String getSudirec() {
		return this.sudirec;
	}

	public void setSudirec(String sudirec) {
		this.sudirec = sudirec;
	}

	public String getSustage() {
		return this.sustage;
	}

	public void setSustage(String sustage) {
		this.sustage = sustage;
	}

	public String getSuName() {
		return this.suName;
	}

	public void setSuName(String suName) {
		this.suName = suName;
	}

}