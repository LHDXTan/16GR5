package com.action;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONArray;

import org.apache.struts2.ServletActionContext;

import com.alibaba.fastjson.JSONObject;
import com.beans.PageBean;
import com.daoimpl.BaseDaoImpl;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.annotations.JsonAdapter;
import com.opensymphony.xwork2.ActionSupport;
import com.pojo.Question;
import com.pojo.Subject;

public class QuestionAction extends ActionSupport {
	private PageBean pb;
	private List<Subject> sublist = new ArrayList();
	private List<Subject> subsuslist = new ArrayList();
	private List<Subject> subjectlist;
	private List<Question> questionlist;
	private Subject sub;
	private Question que;
	private String sustage;
	private String sudirec;
	private Integer qid;	//主键
	private String type;	//类型，单选多选
	private String content;	//题目
	private String optionA;	//选项A
	private String optionB;	//选项B
	private String optionC;	//选项C
	private String optionD;	//选项D
	private String answer;	//答案
	private String hard;	//难度
	private String charpter;//章节
	private Integer suid;	//科目表id，java，3G4G
	private String qtype;
	

	BaseDaoImpl base = new BaseDaoImpl();
	HttpServletRequest request = ServletActionContext.getRequest();
	HttpServletResponse response = ServletActionContext.getResponse();
	
	
    //笔试题显示页面信息
	public String bslist() throws IOException{
		System.out.println("dadasdasdsadasd！！！");
		HttpServletResponse response = ServletActionContext.getResponse();
		response.setCharacterEncoding("UTF-8");
		int y =  (Integer) request.getSession().getAttribute("y");
		System.out.println(y);
		PrintWriter out = response.getWriter();
		List list=base.getObjects("from Question where suid='"+y+"' and qtype='笔试题'");
		Gson gson = new Gson();

       String stt=gson.toJson(list);
		System.out.println(stt);
		out.print(stt);
		out.flush();
		out.close();
		return null;
		}
	
	//机试题显示页面信息
	public String jslist() throws IOException{
		System.out.println("机试题查询方法！！！");
		HttpServletResponse response = ServletActionContext.getResponse();
		response.setCharacterEncoding("UTF-8");
		int yy =  (Integer) request.getSession().getAttribute("yy");
		PrintWriter out = response.getWriter();
		List list=base.getObjects("from Question where suid='"+yy+"' and qtype='机试题'");
		Gson gson = new Gson();
		String result = gson.toJson(list);
		out.print(result);
		out.flush();
		out.close();
		return null;
		}
	
	//Gson笔试题添加
	public String bsadd(){
		System.out.println("进入笔试题添加");
		Question q = new Question();
		q.setType(type);
		q.setContent(content);
		q.setOptionA("A");
		q.setOptionB("B");
		q.setOptionC("C");
		q.setOptionD("D");
		q.setAnswer(answer);
		q.setHard(hard);
		q.setCharpter(charpter);
		int y =  (Integer) request.getSession().getAttribute("y");
		System.out.println(y);
		sub = (Subject)base.getObjectById(Subject.class, y);
		q.setSubject(sub);
		q.setQtype("笔试题");
		base.add(q);
		return "tobslist";
		}
	
	//Gson机试题添加
	public String jsadd(){
		System.out.println("进入机试题添加");
		Question q = new Question();
		q.setType(type);
		q.setContent(content);
		q.setOptionA("A");
		q.setOptionB("B");
		q.setOptionC("C");
		q.setOptionD("D");
		q.setAnswer(answer);
		q.setHard(hard);
		q.setCharpter(charpter);
		int yy =  (Integer) request.getSession().getAttribute("yy");
		System.out.println(yy);
		sub = (Subject)base.getObjectById(Subject.class, yy);
		q.setSubject(sub);
		q.setQtype("机试题");
		base.add(q);
		return "tojslist";
		}
	
	
	
	//Gson笔试题修改
	public String bsupdate(){
		System.out.println("进入笔试题修改");
		System.out.println(qid);
		Question qu = (Question) base.getObjectById(Question.class, qid);
		qu.setType(type);
		qu.setContent(content);
		qu.setAnswer(answer);
		qu.setHard(hard);
		qu.setCharpter(charpter);
		base.update(qu);
		return "tobslist";
		}
	
	//Gson机试题修改
	public String jsupdate(){
		System.out.println("进入机试题修改");
		System.out.println(qid);
		Question qu = (Question) base.getObjectById(Question.class, qid);
		qu.setType(type);
		qu.setContent(content);
		qu.setAnswer(answer);
		qu.setHard(hard);
		qu.setCharpter(charpter);
		base.update(qu);
		return "tojslist";
		}
	
	
	//Gson笔试题删除
	public String bsdelete(){
		System.out.println("进入笔试题删除");
		System.out.println(qid);
		Question qu = (Question) base.getObjectById(Question.class, qid);
		base.delete(qu);
		return "tobslist";
		}
	
	//Gson机试题删除
	public String jsdelete(){
		System.out.println("进入机试题删除");
		System.out.println(qid);
		Question qu = (Question) base.getObjectById(Question.class, qid);
		base.delete(qu);
		return "tojslist";
		}
	
	
	    //类型下拉框
		public String typexlk() throws IOException{
			System.out.println("进到下拉框！！！");
			HttpServletResponse response = ServletActionContext.getResponse();
	        response.setCharacterEncoding("utf-8");
			PrintWriter out = response.getWriter();
			List list = new ArrayList();
			Question qu = new Question();
			qu.setType("单选");
			list.add(qu);
			
			Question qu1 = new Question();
			qu1.setType("多选");
			list.add(qu1);
			
			Gson gson = new Gson();
			String result = gson.toJson(list);
			out.print(result);
			out.flush();
			out.close();
			return null;
		}
		
		//难度下拉框
		public String hardxlk() throws IOException{
			System.out.println("进到下拉框！！！");
			HttpServletResponse response = ServletActionContext.getResponse();
	        response.setCharacterEncoding("utf-8");
			PrintWriter out = response.getWriter();
			List list = new ArrayList();
			Question qu = new Question();
			qu.setHard("简单");
			list.add(qu);
			
			Question qu1 = new Question();
			qu1.setHard("一般");
			list.add(qu1);
			
			Question qu2 = new Question();
			qu2.setHard("困难");
			list.add(qu2);
			
			Gson gson = new Gson();
			String result = gson.toJson(list);
			out.print(result);
			out.flush();
			out.close();
			return null;
		}
	
	
/************************原先的方法**************************************/	
	//修改机试试题
	public String updComputerQuestion() throws IOException{
		response.setContentType("text;charset=UTF-8");
		PrintWriter out = response.getWriter();
		Question q = (Question)base.getObjectById(Question.class, que.getQid());
		q.setType(que.getType());
		q.setContent(que.getContent());
		q.setHard(que.getHard());
		q.setCharpter(que.getCharpter());
		q.setAnswer(que.getAnswer());
		int flag = base.update(q);
		if(flag==1){
			out.print(1);
		} else {
			out.print(0);
		}
		return null;
	}
	
	//去修改机试试题页面
	public String toComputerUpdate(){
		que = (Question)base.getObjectById(Question.class, que.getSuid());
		return "toComputerQuestion";
	}
	
	//添加机试试题
	public String addComputerQuestion() throws IOException{
		int flag = 0;
		response.setContentType("text;charset=UTF-8");
		PrintWriter out = response.getWriter();
		if(!"".equals(que.getContent()) ){
			que.setOptionA("A");
			que.setOptionB("B");
			que.setOptionC("C");
			que.setOptionD("D");
			sub = (Subject)base.getObjectById(Subject.class, que.getSuid());
			que.setSubject(sub);
			que.setQtype("机试题");
			flag = base.add(que);
		}
		out.print(flag);
		return null;
	}
	
	//去机试添加试题页面
	public String toAddComputerQuestion(){
		sub = (Subject)base.getObjectById(Subject.class, que.getSuid());
		return "addComputerQuestion";
	}
	
	//获取机试试题列表
	public String selComputerTestQuestion(){
		int up = 1;		//默认显示第一页
		if(pb!=null){
			up = pb.getP();
			if(up>pb.getPagetotal()){
				up = pb.getPagetotal();
			}
		}
		pb = base.getComputerQuestion(sub,up);
		questionlist = pb.getQuestionlist();
		request.getSession().setAttribute("yy", sub.getSuid());
		sub = (Subject)base.getObjectById(Subject.class, sub.getSuid());
		return "computerTest";
	}
	
	//查询试题、科目、方向
	public String selectSub(){
		sublist = base.getSusSelect();
		subsuslist = base.getSudSelect();
		String sql = null;
		if(!("0").equals(sub.getSudirec()) && !("0").equals(sub.getSustage())){
			sql = "from Subject where sudirec ='"+sub.getSudirec()+"' and sustage = '"+sub.getSustage()+"'";
		} else if(!("0").equals(sub.getSudirec())){
			sql = "from Subject where sudirec ='"+sub.getSudirec()+"'";
		} else if(!("0").equals(sub.getSustage())){
			sql = "from Subject where sustage ='"+sub.getSustage()+"'";
		} else if(("0").equals(sub.getSudirec()) || ("0").equals(sub.getSustage())){
			return "toSubjectAll";
		}
		subjectlist = base.getObjects(sql);
		return "sub";
	}
	
	
	//Gson查询试题、科目、方向下拉框
	public String sus() throws IOException{
		System.out.println("进到sus方法体！！！");
		HttpServletResponse response = ServletActionContext.getResponse();
        response.setCharacterEncoding("utf-8");
		PrintWriter out = response.getWriter();
			
		 List list= base.getObjects("from Subject");
//			Subject subject = new Subject();
//			subject.setSustage("G1");
//			list.add(subject);
		 
		Gson  gson = new Gson();
	    String result=	gson.toJson(list);
		System.out.println(result);
		out.print(result);
		out.flush();
		out.close();
		
		return null;
		}

	
	
	//删除试题
	public String delQestion() throws IOException{
		response.setContentType("text;charset=UTF-8");
		PrintWriter out = response.getWriter();
		que = (Question)base.getObjectById(Question.class, que.getQid());
		int flag = base.delete(que);
		//修改题数
		String qtype = que.getQtype();
		sub = (Subject)base.getObjectById(Subject.class, que.getSuid());
		if("机试题".equals(qtype)){
			sub.setComputernub(sub.getComputernub()-1);
		} else {
			sub.setPennub(sub.getPennub()-1);
		}
		flag = base.update(sub);
		out.print(flag);
		return null;
	}
	
	//添加笔试试题
	public String addQuestion() throws IOException{
		int flag = 0;
		response.setContentType("text;charset=UTF-8");
		PrintWriter out = response.getWriter();
		if(!"".equals(que.getAnswer()) && !"".equals(que.getCharpter()) && !"".equals(que.getContent())
			&& !"".equals(que.getHard()) && !"".equals(que.getType())  ){
			que.setOptionA("A");
			que.setOptionB("B");
			que.setOptionC("C");
			que.setOptionD("D");
			sub = (Subject)base.getObjectById(Subject.class, que.getSuid());
			que.setSubject(sub);
			que.setQtype("笔试题");
			flag = base.add(que);
		}
		out.print(flag);
		return null;
	}
	
	//去添加笔试页面
	public String toAdd(){
		if(que.getSuid()!=null){
			sub = (Subject)base.getObjectById(Subject.class, que.getSuid());
			return "addQuestion";
		}
		return null;
	}
	
	//笔试修改
	public String updQuestion() throws IOException{
		response.setContentType("text;charset=UTF-8");
		PrintWriter out = response.getWriter();
		Question q = (Question)base.getObjectById(Question.class, que.getQid());
		q.setAnswer(que.getAnswer());
		q.setCharpter(que.getCharpter());
		q.setContent(que.getContent());
		q.setHard(que.getHard());
		q.setType(que.getType());
		int flag = base.update(q);
		if(flag==1){
			out.print(1);
		} else {
			out.print(0);
		}	
		return null;
	}
	
	
	
	//去笔试修改页面
	public String toUpdate() throws IOException{
		que = (Question)base.getObjectById(Question.class, que.getSuid());
		request.setAttribute("s", que.getAnswer());
		return "toTestQuestion";
	}
	
	//获取笔试试题列表
	public String selQuestion(){
		int up = 1;		//默认显示第一页
		if(pb!=null){
			up = pb.getP();
			if(up>pb.getPagetotal()){
				up = pb.getPagetotal();
			}
		}
		pb = base.getPentQuestion(sub,up);
		questionlist = pb.getQuestionlist();
		request.getSession().setAttribute("y", sub.getSuid());
		sub = (Subject) base.getObjectById(Subject.class, sub.getSuid());
		return "pentest";
	}
	
	//获取科目
	public String selSubject(){
		subjectlist = base.getQuestionNub();
		if(subjectlist.size()!=0){
			sublist = base.getSusSelect();
			subsuslist = base.getSudSelect();
		}
		return "toSubject";
	}

	public List<Subject> getSubjectlist() {
		return subjectlist;
	}

	public void setSubjectlist(List<Subject> subjectlist) {
		this.subjectlist = subjectlist;
	}

	public List<Question> getQuestionlist() {
		return questionlist;
	}

	public void setQuestionlist(List<Question> questionlist) {
		this.questionlist = questionlist;
	}

	public Subject getSub() {
		return sub;
	}

	public void setSub(Subject sub) {
		this.sub = sub;
	}

	public Question getQue() {
		return que;
	}

	public void setQue(Question que) {
		this.que = que;
	}

	public List<Subject> getSublist() {
		return sublist;
	}

	public void setSublist(List<Subject> sublist) {
		this.sublist = sublist;
	}
	/**
	 * @return the subsuslist
	 */
	public List<Subject> getSubsuslist() {
		return subsuslist;
	}

	/**
	 * @param subsuslist the subsuslist to set
	 */
	public void setSubsuslist(List<Subject> subsuslist) {
		this.subsuslist = subsuslist;
	}

	public PageBean getPb() {
		return pb;
	}

	public void setPb(PageBean pb) {
		this.pb = pb;
	}

	public String getSustage() {
		return sustage;
	}

	public void setSustage(String sustage) {
		this.sustage = sustage;
	}

	public Integer getQid() {
		return qid;
	}

	public void setQid(Integer qid) {
		this.qid = qid;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getOptionA() {
		return optionA;
	}

	public void setOptionA(String optionA) {
		this.optionA = optionA;
	}

	public String getOptionB() {
		return optionB;
	}

	public void setOptionB(String optionB) {
		this.optionB = optionB;
	}

	public String getOptionC() {
		return optionC;
	}

	public void setOptionC(String optionC) {
		this.optionC = optionC;
	}

	public String getOptionD() {
		return optionD;
	}

	public void setOptionD(String optionD) {
		this.optionD = optionD;
	}

	public String getAnswer() {
		return answer;
	}

	public void setAnswer(String answer) {
		this.answer = answer;
	}

	public String getHard() {
		return hard;
	}

	public void setHard(String hard) {
		this.hard = hard;
	}

	public String getCharpter() {
		return charpter;
	}

	public void setCharpter(String charpter) {
		this.charpter = charpter;
	}

	public Integer getSuid() {
		return suid;
	}

	public void setSuid(Integer suid) {
		this.suid = suid;
	}

	public String getQtype() {
		return qtype;
	}

	public void setQtype(String qtype) {
		this.qtype = qtype;
	}

	
	public String getSudirec() {
		return sudirec;
	}

	public void setSudirec(String sudirec) {
		this.sudirec = sudirec;
	}
	
}
