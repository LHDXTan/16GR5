package com.action;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.ServletActionContext;

import com.daoimpl.BaseDaoImpl;
import com.google.gson.Gson;

import com.opensymphony.xwork2.ActionSupport;
import com.pojo.Juese;

public class LoginAction extends ActionSupport {
	private Juese juese;
	private Integer jid;	//角色ID
	private String jname;	//角色名称
	private String nam;
	private String pwd;
	private String role;
	HttpServletRequest request = ServletActionContext.getRequest();
	HttpServletResponse response = ServletActionContext.getResponse();
	BaseDaoImpl base = new BaseDaoImpl();
	
	//退出系统
	public String logout(){
		request.getSession().invalidate();
		return "out";
	}
	
	public String xlk() throws IOException{
		System.out.println("进到方法体！！！");
		HttpServletResponse response = ServletActionContext.getResponse();
        response.setCharacterEncoding("utf-8");
		PrintWriter out = response.getWriter();
		
		List list=(ArrayList) base.getObjects(" from Juese");
		
		System.out.println(list);

		Gson gson = new Gson();
		String result = gson.toJson(list);
		System.out.println(result);
		out.print(result);
		out.flush();
		out.close();
		return null;
		}
	
	
	public String userLogin(){
		System.out.println("登录成功！！！");
		//HttpServletRequest request = ServletActionContext.getRequest();
		if(!"".equals(nam) && !"".equals(pwd)){
			List list = base.login(nam, pwd, role);
			if(list.size()==0){
				request.setAttribute("error", "账号或密码错误");
				return "error";
			} else {
				request.getSession().setAttribute("role", role);
					
				return "success";
			}
		}
		return null;
	}
	/**
	 * @return the nam
	 */
	public String getNam() {
		return nam;
	}
	/**
	 * @return the pwd
	 */
	public String getPwd() {
		return pwd;
	}
	/**
	 * @return the role
	 */
	
	/**
	 * @param nam the nam to set
	 */
	public void setNam(String nam) {
		this.nam = nam;
	}
	/**
	 * @param pwd the pwd to set
	 */
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	/**
	 * @param role the role to set
	 */
	

	public Juese getJuese() {
		return juese;
	}

	public void setJuese(Juese juese) {
		this.juese = juese;
	}

	public Integer getJid() {
		return jid;
	}

	public void setJid(Integer jid) {
		this.jid = jid;
	}

	public String getJname() {
		return jname;
	}

	public void setJname(String jname) {
		this.jname = jname;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}
	
}
