package com.pojo;

/**
 * Teacher entity. @author MyEclipse Persistence Tools
 */

public class Teacher implements java.io.Serializable {

	// Fields

	private Integer tid;		//教师ID
	private Integer jid;		//角色ID
	private String loginuser;	//教师账号
	private String password;	//密码
	private String tname;		//教师姓名
	private String tsex;		//教师性别
	private String tbirthday;	//生日
	private String teducation;	//学历
	private String tphone;		//联系电话
	private String tgangwei;	//岗位
	private String tbeizhu;		//备注

	// Constructors

	/** default constructor */
	public Teacher() {
	}

	/** minimal constructor */
	public Teacher(Integer tid, Integer jid, String loginuser, String password,
			String tname, String tsex, String tgangwei) {
		this.tid = tid;
		this.jid = jid;
		this.loginuser = loginuser;
		this.password = password;
		this.tname = tname;
		this.tsex = tsex;
		this.tgangwei = tgangwei;
	}

	/** full constructor */
	public Teacher(Integer tid, Integer jid, String loginuser, String password,
			String tname, String tsex, String tbirthday, String teducation,
			String tphone, String tgangwei, String tbeizhu) {
		this.tid = tid;
		this.jid = jid;
		this.loginuser = loginuser;
		this.password = password;
		this.tname = tname;
		this.tsex = tsex;
		this.tbirthday = tbirthday;
		this.teducation = teducation;
		this.tphone = tphone;
		this.tgangwei = tgangwei;
		this.tbeizhu = tbeizhu;
	}

	// Property accessors

	public Integer getTid() {
		return this.tid;
	}

	public void setTid(Integer tid) {
		this.tid = tid;
	}

	public Integer getJid() {
		return this.jid;
	}

	public void setJid(Integer jid) {
		this.jid = jid;
	}

	public String getLoginuser() {
		return this.loginuser;
	}

	public void setLoginuser(String loginuser) {
		this.loginuser = loginuser;
	}

	public String getPassword() {
		return this.password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getTname() {
		return this.tname;
	}

	public void setTname(String tname) {
		this.tname = tname;
	}

	public String getTsex() {
		return this.tsex;
	}

	public void setTsex(String tsex) {
		this.tsex = tsex;
	}

	public String getTbirthday() {
		return this.tbirthday;
	}

	public void setTbirthday(String tbirthday) {
		this.tbirthday = tbirthday;
	}

	public String getTeducation() {
		return this.teducation;
	}

	public void setTeducation(String teducation) {
		this.teducation = teducation;
	}

	public String getTphone() {
		return this.tphone;
	}

	public void setTphone(String tphone) {
		this.tphone = tphone;
	}

	public String getTgangwei() {
		return this.tgangwei;
	}

	public void setTgangwei(String tgangwei) {
		this.tgangwei = tgangwei;
	}

	public String getTbeizhu() {
		return this.tbeizhu;
	}

	public void setTbeizhu(String tbeizhu) {
		this.tbeizhu = tbeizhu;
	}

}