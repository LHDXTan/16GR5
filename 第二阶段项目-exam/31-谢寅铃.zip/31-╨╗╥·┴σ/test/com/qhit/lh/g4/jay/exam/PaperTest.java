package com.qhit.lh.g4.jay.exam;

import org.junit.Test;

import com.qhit.lh.g4.jay.exam.common.dao.BaseDao;
import com.qhit.lh.g4.jay.exam.kmgl.bean.Course;
import com.qhit.lh.g4.jay.exam.sjgl.bean.Paper;
import com.qhit.lh.g4.jay.exam.sjgl.bean.PaperClass;

public class PaperTest extends BaseDao {

	@Test
	public void addPaper(){
		
	}
}
