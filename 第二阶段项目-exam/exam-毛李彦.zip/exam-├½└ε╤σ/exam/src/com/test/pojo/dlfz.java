package com.test.pojo;

public class dlfz {

	private String name;
	private String pwd;
	private String role;
	private String roles;
	private String roless; //试题随机添加
	//按条件查询
	private String jszh;
	private String jsxm;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getJszh() {
		return jszh;
	}
	public void setJszh(String jszh) {
		this.jszh = jszh;
	}
	public String getJsxm() {
		return jsxm;
	}
	public void setJsxm(String jsxm) {
		this.jsxm = jsxm;
	}
	public String getRoles() {
		return roles;
	}
	public void setRoles(String roles) {
		this.roles = roles;
	}
	public String getRoless() {
		return roless;
	}
	public void setRoless(String roless) {
		this.roless = roless;
	}
	
	
}
