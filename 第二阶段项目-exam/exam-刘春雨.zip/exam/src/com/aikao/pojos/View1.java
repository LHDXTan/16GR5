package com.aikao.pojos;

/**
 * View1Id entity. @author MyEclipse Persistence Tools
 */

public class View1 implements java.io.Serializable {

	// Fields

	private Integer suId;
	private String suName;
	private String sustage;
	private String sudirec;
	private Integer num1;
	private Integer num2;

	// Constructors

	/** default constructor */
	public View1() {
	}

	/** minimal constructor */
	public View1(Integer suId, String suName, String sustage, String sudirec) {
		this.suId = suId;
		this.suName = suName;
		this.sustage = sustage;
		this.sudirec = sudirec;
	}

	/** full constructor */
	public View1(Integer suId, String suName, String sustage, String sudirec,
			Integer num1, Integer num2) {
		this.suId = suId;
		this.suName = suName;
		this.sustage = sustage;
		this.sudirec = sudirec;
		this.num1 = num1;
		this.num2 = num2;
	}

	// Property accessors

	public Integer getSuId() {
		return this.suId;
	}

	public void setSuId(Integer suId) {
		this.suId = suId;
	}

	public String getSuName() {
		return this.suName;
	}

	public void setSuName(String suName) {
		this.suName = suName;
	}

	public String getSustage() {
		return this.sustage;
	}

	public void setSustage(String sustage) {
		this.sustage = sustage;
	}

	public String getSudirec() {
		return this.sudirec;
	}

	public void setSudirec(String sudirec) {
		this.sudirec = sudirec;
	}

	public Integer getNum1() {
		return this.num1;
	}

	public void setNum1(Integer num1) {
		this.num1 = num1;
	}

	public Integer getNum2() {
		return this.num2;
	}

	public void setNum2(Integer num2) {
		this.num2 = num2;
	}

	public boolean equals(Object other) {
		if ((this == other))
			return true;
		if ((other == null))
			return false;
		if (!(other instanceof View1))
			return false;
		View1 castOther = (View1) other;

		return ((this.getSuId() == castOther.getSuId()) || (this.getSuId() != null
				&& castOther.getSuId() != null && this.getSuId().equals(
				castOther.getSuId())))
				&& ((this.getSuName() == castOther.getSuName()) || (this
						.getSuName() != null && castOther.getSuName() != null && this
						.getSuName().equals(castOther.getSuName())))
				&& ((this.getSustage() == castOther.getSustage()) || (this
						.getSustage() != null && castOther.getSustage() != null && this
						.getSustage().equals(castOther.getSustage())))
				&& ((this.getSudirec() == castOther.getSudirec()) || (this
						.getSudirec() != null && castOther.getSudirec() != null && this
						.getSudirec().equals(castOther.getSudirec())))
				&& ((this.getNum1() == castOther.getNum1()) || (this.getNum1() != null
						&& castOther.getNum1() != null && this.getNum1()
						.equals(castOther.getNum1())))
				&& ((this.getNum2() == castOther.getNum2()) || (this.getNum2() != null
						&& castOther.getNum2() != null && this.getNum2()
						.equals(castOther.getNum2())));
	}

	public int hashCode() {
		int result = 17;

		result = 37 * result
				+ (getSuId() == null ? 0 : this.getSuId().hashCode());
		result = 37 * result
				+ (getSuName() == null ? 0 : this.getSuName().hashCode());
		result = 37 * result
				+ (getSustage() == null ? 0 : this.getSustage().hashCode());
		result = 37 * result
				+ (getSudirec() == null ? 0 : this.getSudirec().hashCode());
		result = 37 * result
				+ (getNum1() == null ? 0 : this.getNum1().hashCode());
		result = 37 * result
				+ (getNum2() == null ? 0 : this.getNum2().hashCode());
		return result;
	}

}