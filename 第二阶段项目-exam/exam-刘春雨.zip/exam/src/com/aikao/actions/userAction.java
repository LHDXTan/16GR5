package com.aikao.actions;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts2.ServletActionContext;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.aikao.dao.HibernateSessionFactory;
import com.aikao.dao.fivejdbc;
import com.aikao.pojos.*;
import com.opensymphony.xwork2.ActionContext;

public class userAction implements fivejdbc {

	private Session sess=HibernateSessionFactory.getSession();
	private Transaction ts=sess.beginTransaction();
	private String name;
	private String pwd;
	private int type;
	private Adminuser ad;
	private Teacher tc;
	private Student sd;
	
	public String checkUser(){
		if("".equals(name) || "".equals(pwd)){
			return "login";
		}else{
			String hql="";
			if(type==1){  hql="select s from Student s where s.loginuser=? and s.password=?";  }
			else if(type==2){  hql="select t from Teacher t where t.loginuser=? and t.password=?";  }
			else if(type==3){  hql="select a from Adminuser a where a.loginuser=? and a.password=?";  }
				List list=sess.createQuery(hql).setString(0, name).setString(1, pwd).list();
				if(list.size()==0){return "login";}else{
					ServletActionContext.getRequest().getSession().setAttribute("type",type);
					ServletActionContext.getRequest().getSession().setAttribute("name",name);
					return "index";
				}
		}
	}
	@Override
	public String select() {
		// TODO Auto-generated method stub
		return "showinfor";
	}

	@Override
	public String add() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String del() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String toUpdate() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String update() {
		// TODO Auto-generated method stub
		return null;
	}

	
	//==============分隔线==================
	public Adminuser getAd() {
		return ad;
	}
	public void setAd(Adminuser ad) {
		this.ad = ad;
	}
	public Teacher getTc() {
		return tc;
	}
	public void setTc(Teacher tc) {
		this.tc = tc;
	}
	public Student getSd() {
		return sd;
	}
	public void setSd(Student sd) {
		this.sd = sd;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	public int getType() {
		return type;
	}
	public void setType(int type) {
		this.type = type;
	}
	
	

}
