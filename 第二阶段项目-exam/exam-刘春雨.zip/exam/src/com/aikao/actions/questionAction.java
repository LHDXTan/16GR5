package com.aikao.actions;

import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.ServletActionContext;
import org.hibernate.Hibernate;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.transform.Transformers;

import com.aikao.dao.HibernateSessionFactory;
import com.aikao.dao.fivejdbc;
import com.aikao.pojos.*;

public class questionAction implements fivejdbc {
	private Session sess=HibernateSessionFactory.getSession();
	private Transaction ts=sess.beginTransaction();
	
	private Subject su;
	private Question ques;
	private Paperinfo pp;
	@Override
	public String select() {//查询所有科目笔试机试题个数
		// TODO Auto-generated method stub
		String hql="select v from View1 v ";
		List sulist=sess.createQuery(hql) .list();
		ServletActionContext.getRequest().getSession().setAttribute("sulist",sulist);
		return "show";
	}

	@Override
	public String add() {
		// TODO Auto-generated method stub
		HttpServletRequest req=ServletActionContext.getRequest();
		String[] str=req.getParameterValues("quest.answer");
		String answer="";
		for(int i=0;i<str.length;i++){
			answer=answer+str[i];
		}
		ques.setAnswer(answer);
		System.out.println(ques.getOptionC());
		sess.save(ques);
		ts.commit();
		HibernateSessionFactory.closeSession();
		return null;
	}

	@Override
	public String del() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String toUpdate() {
		// TODO Auto-generated method stub
		String hql="select ques from Question ques where ques.qid=?";
		List qlist=sess.createQuery(hql).setInteger(0, ques.getQid()).list();
		ques=(Question) qlist.get(0);
		ServletActionContext.getRequest().getSession().setAttribute("ques",ques);
		ServletActionContext.getRequest().getSession().setAttribute("suname",su.getSuName());
		return null;
	}

	@Override
	public String update() {
		// TODO Auto-generated rmethod stub
		HttpServletRequest req=ServletActionContext.getRequest();
		HttpServletResponse res=ServletActionContext.getResponse();
		String[] str=req.getParameterValues("quest.answer");
		String answer="";
		for(int i=0;i<str.length;i++){
			answer=answer+str[i];
		}
		Question q=(Question) sess.get(Question.class, ques.getQid());
				q.setType(ques.getType());
				q.setContent(ques.getContent());
				q.setOptionA(ques.getOptionA());
				q.setOptionB(ques.getOptionB());
				q.setOptionC(ques.getOptionC());
				q.setOptionD(ques.getOptionD());
				q.setHard(ques.getHard());
				q.setCharpter(ques.getCharpter());
				q.setPtype(ques.getPtype());
				q.setAnswer(answer);
		sess.update(q);
		ts.commit();
		HibernateSessionFactory.closeSession();
		return null;
	}
	
	public String select1(){//按照就业方向查询
		String hql="select v from View1 v  where v.sudirec=? ";
		List sulist=sess.createQuery(hql).setString(0, su.getSudirec()).list();
		ServletActionContext.getRequest().getSession().setAttribute("sulist",sulist);
		return "show";
	}
	public String select2(){//按照阶段查询
		String hql="select v from View1 v  where v.sustage=? ";
		List sulist=sess.createQuery(hql).setString(0, su.getSustage()).list();
		ServletActionContext.getRequest().getSession().setAttribute("sulist",sulist);
		return "show";
	}
	
	public String select3(){//查询试题
		String hql="select ques from Question ques where ques.suid=? and ques.ptype=?  ";
		List queslist=sess.createQuery(hql).setInteger(0, ques.getSuid()).setString(1, ques.getPtype()).list();
		ServletActionContext.getRequest().getSession().setAttribute("queslist",queslist);
		ServletActionContext.getRequest().setAttribute("name", su.getSuName());
		ServletActionContext.getRequest().setAttribute("type", ques.getPtype());
		return "ques";
	}
	public String toadd(){
		String hql="select su from Subject su";
		List slist=sess.createQuery(hql).list();
		HashMap map=new HashMap();
		for(int i=0;i<slist.size();i++){
			Subject s=(Subject) slist.get(i);
			map.put(s.getSuId(), s.getSuName());
		}
		ServletActionContext.getRequest().getSession().setAttribute("map",map);
		return null;
	}
	
	//==============分隔线==================
	public Subject getSu() {
		return su;
	}

	public void setSu(Subject su) {
		this.su = su;
	}

	public Question getQues() {
		return ques;
	}

	public void setQues(Question ques) {
		this.ques = ques;
	}

	public Paperinfo getPp() {
		return pp;
	}

	public void setPp(Paperinfo pp) {
		this.pp = pp;
	}

}
