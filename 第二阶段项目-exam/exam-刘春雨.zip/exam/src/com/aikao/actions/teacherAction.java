package com.aikao.actions;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import org.apache.struts2.ServletActionContext;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.aikao.dao.HibernateSessionFactory;
import com.aikao.dao.fivejdbc;
import com.aikao.pojos.Teacher;

public class teacherAction implements fivejdbc {
	private Session sess=HibernateSessionFactory.getSession();
	private Transaction ts=sess.beginTransaction();
	
	private Teacher t;
	private List<Teacher> tlist=new ArrayList();
	@Override
	public String select() {
		// TODO Auto-generated method stub
		String hql="select t from Teacher t";
		tlist=sess.createQuery(hql).list();
//		System.out.println(tlist.size());
		ServletActionContext.getRequest().getSession().setAttribute("tlist",tlist);
		return "showinfor";
	}

	@Override
	public String add() {
		// TODO Auto-generated method stub
		t.setJid(2);
		sess.save(t);
		ts.commit();
		HibernateSessionFactory.closeSession();
		return "showinfor";
	}

	@Override
	public String del() {
		// TODO Auto-generated method stub
		Teacher t1=(Teacher) sess.get(Teacher.class, new Integer(t.getTid()));
		sess.delete(t1);
		ts.commit();
		HibernateSessionFactory.closeSession();
		return "toshowinfor";
	}

	@Override
	public String toUpdate() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String update() {
		// TODO Auto-generated method stub
		return null;
	}
	
	public String rePwd(){//修改密码
		System.out.println(t.getTid());
		Teacher t1=(Teacher) sess.get(Teacher.class, new Integer(t.getTid()));
		t1.setPassword("123");
		ts.commit();
		HibernateSessionFactory.closeSession();
		return "toshowinfor";
	}
	
	public String selectzh(){
		System.out.println(t.getLoginuser()+t.getTname()+t.getTgangwei());
		if(!"".equals(t.getLoginuser())&&"".equals(t.getTname())&&"".equals(t.getTgangwei())){
			
		}
		return null;
	}
	//==============分隔线==================

	public Teacher getT() {
		return t;
	}

	public void setT(Teacher t) {
		this.t = t;
	}


}
