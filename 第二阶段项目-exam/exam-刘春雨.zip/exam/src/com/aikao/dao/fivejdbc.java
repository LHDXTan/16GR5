package com.aikao.dao;

public interface fivejdbc {
	
	    public String select();
	    
	    public String add();
	    
	    public String del();
	    
	    public String toUpdate();
	    
	    public String update();

}
