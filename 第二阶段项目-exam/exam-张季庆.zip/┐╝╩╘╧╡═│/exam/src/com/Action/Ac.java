package com.Action;

import java.util.List;

import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.Action;
import com.test.Fz.DlFz;
import com.test.Fz.Question;
import com.test.Fz.TikuFz;
import com.test.dao.SjDao;

public class Ac implements Action {
	private DlFz user;
	private TikuFz tk;
	private Question question;
	
	SjDao d=new SjDao();
	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}


	//登陆
	public String dl(){
		System.out.println(user.getName());
		System.out.println(user.getPwd());
		System.out.println(user.getRole());
		
		  int a=  d.dlyz(user.getRole(),user.getName(),user.getPwd());
		
		
		if(a==0){	
			ServletActionContext.getRequest().getSession().setAttribute("cuo", "登陆失败，请重新登陆");
			return "login";
		}
		else{
			ServletActionContext.getRequest().getSession().setAttribute("qx",user.getRole());
		return "zhu";}
	}


	//题库主页面查询
	public String tukua(){
		System.out.println("这是题库主页面查询");
	

		   List<Object[]> t = d.tikud(tk.getSudirec(), tk.getSustage());
		   

		   ServletActionContext.getRequest().getSession().setAttribute("tt",t);
		
		return "tkgl";
	}
	
	
	//查询对应阶段科目的题
	public String TKa(){
		List<Object[]> tdy=d.Tkc();
	  
		 ServletActionContext.getRequest().getSession().setAttribute("tdy",tdy);
	
	
	
		return "tkdy";
		 
	}
	
	
	
	
	
	//转对应题的添加和修改
	public String zba(){
		System.out.println("这是添加和修改");
		String	tiku= ServletActionContext.getRequest().getParameter("tiku");
		System.out.println("tiku"+tiku);
		if(tiku.equals("1")){
		String suid=	ServletActionContext.getRequest().getParameter("suid");
		 ServletActionContext.getRequest().getSession().setAttribute("suid",suid);
		System.out.println("suid"+suid);
		return "tmglt";
		}
		
		else{System.out.println("你点击的不是添加");}
		
		return "tmglt";
	}
	
	//对应题的添加
	public String Tktja(){
		System.out.println("这是添加");
		
		String suid =(String) ServletActionContext.getRequest().getSession().getAttribute("suid");
		int su=(Integer.parseInt(suid));
		System.out.println("转过来的suid"+su);
		question.setSuid(su);
		   String b= (String)ServletActionContext.getRequest().getSession().getAttribute("aaa");
		System.out.println("转过来的机试或者笔试"+b);
		question.setPtype(b);
		//下面是去除文本插件的html标签
		String timu =question.getContent();
		String content=timu.replaceAll("</?[^>]+>", "");
		question.setContent(content);
		
		String answer=ServletActionContext.getRequest().getParameter("answer");
		question.setAnswer(answer);
		//输出测试
		System.out.println("笔试机试"+question.getPtype());
		System.out.println("单选多选"+question.getType());
		System.out.println("题目"+question.getContent());
		System.out.println("选项a"+question.getOptionA());
		System.out.println("选项b"+question.getOptionB());
		System.out.println("选项c"+question.getOptionC());
		System.out.println("选项d"+question.getOptionD());
		System.out.println("简易"+question.getHard());
		System.out.println("章节"+question.getCharpter());
		System.out.println("答案"+question.getAnswer());
		System.out.println("suid"+question.getSuid());
		
		         d.tjshiti(question);
		
		return null;
		
	}
	
	//对应题的修改
	public String Tkxga(){
		System.out.println("这是修改");
		return null;
		
	}
	
	//对应题的删除
	public String Tksca(){
		System.out.println("这是删除");
		String qid=	ServletActionContext.getRequest().getParameter("qid");
		System.out.println("这是删除传过来的suid"+qid);
		int Sid=Integer.parseInt(qid);
	        System.out.println(Sid);
	
            d.scshiti(Sid);
		
		return "zhu";
		
	}
	

	
	
	
	
	
	
	
	
	
	
	
	
	//封装
	public DlFz getUser() {
		return user;
	}


	public void setUser(DlFz user) {
		this.user = user;
	}


	
	
	public TikuFz getTk() {
		return tk;
	}


	public void setTk(TikuFz tk) {
		this.tk = tk;
	}


	public Question getQuestion() {
		return question;
	}


	public void setQuestion(Question question) {
		this.question = question;
	}
	
	
	
	
	
	
	
}
