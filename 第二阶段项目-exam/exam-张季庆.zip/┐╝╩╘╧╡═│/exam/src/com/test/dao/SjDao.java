package com.test.dao;

import org.apache.struts2.ServletActionContext;
import org.hibernate.Query;
import org.hibernate.Session;
import org.omg.CORBA.PUBLIC_MEMBER;

import com.test.Fz.Adminuser;
import com.test.Fz.Question;
import com.test.Fz.Student;
import com.test.Fz.Teacher;
import com.test.Fz.TikuFz;

import antlr.collections.List;

public class SjDao {
	String sql;
	Session se = HibernateSessionFactory.getSession();

	public int dlyz(int i,String l,String p){
	    int s=0; 
		
		if(i==1){
				sql="select new Student(a.loginuser,a.password) from Student a where a.loginuser= "+"'"+l+ "'"+" and a.password="+p;
		         Query createQuery = se.createQuery(sql);
			       java.util.List<Student> list = createQuery.list();
			       
			      for(Student a:list){
			    	  System.out.println("你好"+a.getLoginuser());
			    if(a.getPassword()!=null){
			    	s=1;
			    }
			      }
				
		}
		else if(i==2){
			sql="select new Teacher(a.loginuser,a.password) from Teacher a where a.loginuser= "+"'"+l+ "'"+" and a.password="+p;
	         Query createQuery = se.createQuery(sql);
			       java.util.List<Teacher> list = createQuery.list();
			       
			      for(Teacher a:list){
			    	  System.out.println("你好"+a.getLoginuser());
			    	    if(a.getPassword()!=null){
					    	s=1;
					    }
			      }
		}
		else if(i==4){
			sql="select new Adminuser(a.loginuser,a.password) from Adminuser a where a.loginuser= "+"'"+l+ "'"+" and a.password="+p;
		      Query createQuery = se.createQuery(sql);
		       java.util.List<Adminuser> list = createQuery.list();
		       
		      for(Adminuser a:list){
		    	  System.out.println("你好"+a.getLoginuser());
		    	    if(a.getPassword()!=null){
				    	s=1;
				    }
		      }
		}
		
		return s;

	  
	}
	  
	
	//题库总
     public java.util.List<Object[]> tikud(String f,String j){
    	 
//    	 select  su.suId ID,su.suName , su.sudirec ,su.sustage,
//    	 (CASE WHEN num1 IS null then '0' else num1 end) as num1,
//    	 (CASE WHEN num2 IS null then '0' else num2 end) as num2 from
//    	 (select tab1.suid,tab1.num num1,tab2.num num2 from
//    	 (select count(ptype)num,suid  from question where ptype='机试'  group by suid)
//    	 as tab1 FULL  JOIN(select count(ptype)num,suid  from question where ptype='笔试'  group by suid)
//    	 as tab2 on tab1.suid=tab2.suid)as tab3 right join (select * from subject   where sudirec='高软') su on su.suId=tab3.suid

    	 
    	 
    	 sql="select  su.suId ID,su.suName , su.sudirec ,su.sustage,"+
				 "(CASE WHEN num1 IS null then '0' else num1 end) as num1,(CASE WHEN num2 IS null then '0' else num2 end) as num2 from"+ 
				 "(select tab1.suid,tab1.num num1,tab2.num num2 from"+
				 "(select count(ptype)num,suid  from question where ptype='机试'  group by suid)as tab1 "+
				 "FULL  JOIN"+
				 "(select count(ptype)num,suid  from question where ptype='笔试'  group by suid)as tab2 "+
				 "on tab1.suid=tab2.suid)as tab3 "+
				 "right join (select * from subject   where sudirec='"+f+"' and sustage='"+j+"') su on "+
				 "su.suId=tab3.suid";
         
    	 //自己的sql
    	// sql="select s.suName,s.sudirec,s.sustage,q.pType,COUNT(s.suId)as Tsl from subject s, question q where s.suId=q.suid and s.sudirec='"+f+"' and s.sustage='"+j+"' GROUP BY s.suName,s.sudirec,s.sustage,q.pType";
    	 Query createQuery = se.createSQLQuery(sql);
    	 
    	 java.util.List<Object []> list = createQuery.list();
    
		return list;
	       
     }
     
     
     //查询相应科目和阶段的题目
     public java.util.List<Object[]> Tkc(){
    	 String b;
 		System.out.println("这是题库对应查询");
 		String a=	ServletActionContext.getRequest().getParameter("a");
 		 b=	ServletActionContext.getRequest().getParameter("b");
 		 if(b.equals("1")){
 			 b="机试";
 		 }
 		 else{b="笔试";}
 		System.out.println(a);
 		System.out.println(b);
 		Object[] s=(Object[]) ServletActionContext.getRequest().getSession().getAttribute("a"+a);
 		 ServletActionContext.getRequest().getSession().setAttribute("aa",s);
 		ServletActionContext.getRequest().getSession().setAttribute("aaa",b);
 		System.out.println(s[0]);
    	 sql="select * from question q where q.Ptype='"+b+"'and q.suid=( select s.suid from subject s where s.suName='"+s[1]+"' and s.sudirec='"+s[2]+"' and s.sustage='"+s[3]+"' )";
    	 Query createQuery = se.createSQLQuery(sql);
    	 java.util.List<Object []> list = createQuery.list();
    	 
		return list;
   
    	 
    	 
     }
  
   //添加试题的方法
     public Question tjshiti(Question Q){
    	 //使用持久化   在页面的数据直接写到封装类里面   然后传到写好的持久类的接口中 使用
    	 BaseDaoImpl bd=new BaseDaoImpl();
    	 bd.add(Q);
    	 
    	 return null;
     }
     
     
     //删除试题 只要主键传过来就行
     public void scshiti(int qid){
    	Question q=new Question();
    	   q.setQid(qid);
    	   //不能为空             主键是传过来的随时改变的  
           q.setPtype("s");
           q.setType("s");
           q.setContent("s");
           q.setOptionA("s");
           q.setOptionB("s");
           q.setOptionC("c");
           q.setOptionD("s");
           q.setHard("s");
           q.setCharpter("s");
           q.setAnswer("s");
           q.setSuid(1);
      
    	 BaseDaoImpl bd=new BaseDaoImpl();
    	 bd.delete(q);
    	 
    	 
    	 
     }
     
     
}
