package com.test.Fz;

public class TikuFz {
	private String suName;
	private String sudirec;
    private String sustage;
    private String pType;
    private String Tsl;
    
    
    
    
	public String getSuName() {
		return suName;
	}
	public void setSuName(String suName) {
		this.suName = suName;
	}
	public String getSudirec() {
		return sudirec;
	}
	public void setSudirec(String sudirec) {
		this.sudirec = sudirec;
	}
	public String getSustage() {
		return sustage;
	}
	public void setSustage(String sustage) {
		this.sustage = sustage;
	}
	public String getpType() {
		return pType;
	}
	public void setpType(String pType) {
		this.pType = pType;
	}
	public String getTsl() {
		return Tsl;
	}
	public void setTsl(String tsl) {
		Tsl = tsl;
	}
    
    

}
