package com.exam.action;

import java.util.List;

import com.exam.fengzhuang.QuestingDather;
import com.exam.pageinfo.HibernatePublic;
import com.exam.pojo.TestPaper;
import com.opensymphony.xwork2.ActionSupport;
/**
 * 
 * @project exam ��Ŀ����
 * @name papsonQuestions ������   
 * @describe (��һ�仰�������������)
 * @author Chichi ����
 * @time 2018-3-7 ����3:27:55
 */
public class papsonQuestions extends ActionSupport{
    private HibernatePublic session=new HibernatePublic();
    private List<TestPaper> subjects;
    private QuestingDather quest;
	 public String chaquestions(){
		 subjects= session.getObjects("from TestPaper");
		 for(TestPaper a:subjects){
			  System.out.println(a.getTestTime());
		 }
		 System.out.println(subjects.toString());
		 return "set";
	 }
	 public String typecha(){
		 System.out.println(quest.getSname());
		 String sql="select s from TestPaper s where s.state="+quest.getState();
		subjects = session.getObjects(sql);
		 
		 return "set";
	 }
	public List<TestPaper> getSubjects() {
		return subjects;
	}
	public void setSubjects(List<TestPaper> subjects) {
		this.subjects = subjects;
	}
	public QuestingDather getQuest() {
		return quest;
	}
	public void setQuest(QuestingDather quest) {
		this.quest = quest;
	}
	   
	 
}
