package com.exam.action;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.hibernate.Query;
import org.hibernate.Session;

import com.exam.fengzhuang.QuesentList;
import com.exam.fengzhuang.SelectAction;
import com.exam.pageinfo.HibernatePublic;
import com.exam.pageinfo.HibernateSessionFactory;
import com.exam.pojo.Paper;
import com.exam.pojo.Question;
import com.exam.pojo.Subject;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

public class QuestionBank extends ActionSupport {
	private HibernatePublic session=new HibernatePublic();
	private List<QuesentList> dcnList;
	private int suid;
	private List<Question> quest;
	private int id;
	private String type;
	private String name;
	private Question ques;
	private SelectAction select;
	//�õ��׶κͿ�Ŀ
    public String selectList(){
    	dcnList=new ArrayList<QuesentList>();
    	String sql="select su.suId,su.suName,su.sudirec,su.sustage, (CASE WHEN num1 IS null then '0' else num1 end) as num1,(CASE WHEN num2 IS null then '0' else num2 end) as num2 from (select tab1.suid,tab1.num num1,tab2.num num2 from(select count(stype)num,suid from question where stype='����'  group by suid)as tab1 FULL  JOIN(select count(stype)num,suid  from question where stype='����'  group by suid)as tab2 on tab1.suid=tab2.suid)as tab3 right join subject su on su.suId=tab3.suid";
    	List<Object[]> createSQL = session.createSQL(sql);
    	for(int i=0; i<createSQL.size();i++){
    		QuesentList list=new QuesentList();
    		Object[] obj = createSQL.get(i);
    		list.setSuid(Integer.parseInt(obj[0].toString()));   
    		list.setSuname(obj[1].toString());
    		list.setSudirec(obj[2].toString());  			
    		list.setSustage(obj[3].toString());		
    		list.setNum1(Integer.parseInt(obj[4].toString()));
    		list.setNum2(Integer.parseInt(obj[5].toString()));
    	    dcnList.add(list);
    	}  
    	  return "question";
    }
       //�������ѯ
     public String selectbi(){
//        System.out.println(suid);
    	String hql="select q from Question q where q.suid="+suid+"and q.stype='����'";
    	 quest = session.getObjects(hql);
	     System.out.println(suid);
    	 Subject sub = (Subject) session.select(Subject.class, new Integer(suid));
//    	 System.out.println(sub.getSuName());
    	 Map<String, Object> map = ActionContext.getContext().getSession();
    	 map.put("tittle", sub.getSuName());
    	 map.put("type", "����");	 
//    	for (int i = 0; i < quest.size(); i++) {
//    		Question question = quest.get(i);
//    		System.out.println(question.getOptionA());
//		}
    	return "questi";
    }
     //�������ѯ
     public String selectji(){ 
    	 String hql="select q from Question q where q.suid="+suid+"and q.stype='����'";
    	 quest = session.getObjects(hql);
    	 Subject sub = (Subject) session.select(Subject.class, new Integer(suid));
    	 Map<String, Object> map =ActionContext.getContext().getSession();
    	 map.put("tittle", sub.getSuName());
    	 map.put("type", "����");
    	 return "questi";
     }
     //����ɾ��
     public String delete(){
    	 Question qu = (Question) session.select(Question.class, new Integer(id));
    	 session.delete(qu);
         return "select";
     }
     //��������
     public String set(){  	 
    	return "setti";
     }
     public String setprap(){
    	 System.out.println("12321231");
    	 session.set(ques);
    	 return "";
     }
     
     //�����Լ��׶β�ѯ
     public String selectsele(){
    	 System.out.println(select.getSelect1());
    	 System.out.println(select.getSelect2());
    	 String sql2="select su.suId,su.suName , su.sudirec ,su.sustage,(CASE WHEN num1 IS null then '0' else num1 end) as num1,(CASE WHEN num2 IS null then '0' else num2 end) as num2 from (select tab1.suid,tab1.num num1,tab2.num num2 from(select count(stype)num,suid  from question where stype='����' group by suid)as tab1 FULL  JOIN(select count(stype)num,suid  from question where stype='����'  group by suid)as tab2 on tab1.suid=tab2.suid)as tab3 right join (select * from subject   where sustage='"+select.getSelect2()+"' and sudirec='"+select.getSelect1()+"') su on su.suId=tab3.suid";
   	     dcnList=new ArrayList<QuesentList>();
   		 List<Object[]> createSQL1 = session.createSQL(sql2);	
   		  for(int i=0; i<createSQL1.size();i++){
       		QuesentList list=new QuesentList();
       		Object[] obj = createSQL1.get(i);
       		list.setSuid(Integer.parseInt(obj[0].toString()));   
       		list.setSuname(obj[1].toString());
       		list.setSudirec(obj[2].toString());  			
       		list.setSustage(obj[3].toString());		
       		list.setNum1(Integer.parseInt(obj[4].toString()));
       		list.setNum2(Integer.parseInt(obj[5].toString()));
       	    dcnList.add(list);
   		  } 
    	  return "question";
     }
	public List<QuesentList> getDcnList() {
		return dcnList;
	}
	public void setDcnList(List<QuesentList> dcnList) {
		this.dcnList = dcnList;
	}
    
	public int getSuid() {
		return suid;
	}
	public void setSuid(int suid) {
		this.suid = suid;
	}
	public List<Question> getQuest() {
		return quest;
	}

	public void setQuest(List<Question> quest) {
		this.quest = quest;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Question getQues() {
		return ques;
	}
	public void setQues(Question ques) {
		this.ques = ques;
	}
	public SelectAction getSelect() {
		return select;
	}
	public void setSelect(SelectAction select) {
		this.select = select;
	}
    
   
    
    
}
