package com.exam.action;

import java.util.List;
import java.util.Map;

import org.hibernate.Query;
import org.hibernate.Session;

import com.exam.pageinfo.HibernatePublic;
import com.exam.pageinfo.HibernateSessionFactory;
import com.exam.pojo.Adminuser;
import com.exam.pojo.Juese;
import com.exam.pojo.LoginUser;
import com.exam.pojo.Student;
import com.exam.pojo.Teacher;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

public class LoginAction extends ActionSupport {
	private HibernatePublic session=new HibernatePublic();
	private List<Juese> list ;
	private int select;
	private LoginUser user;
	//��ȡ���ݿ���û�����
    public String selectlist(){
    	list= session.getObjects("from Juese");
//    	for (int i = 0; i < list.size(); i++) {
//			System.out.println(list.get(i));
//		}
    	 return "login";
    }
    //��ͬ���͵��û���½ҵ�����
    public String select(){
    	if(select==1){
    	  int c = loginutil("Adminuser",1);
      	    if(c==1){
      		  return "admin";
      	    }
      	    return "index";
    	    }else if(select==2){
    	    	System.out.println("132123");
    	    int a = loginutil("Teacher",2);
       	       if(a==1){
       		  return "admin";
    	   }
       	    return "index";
    	   }
    	    int i = loginutil("Student",3);
    	      if(i==1){
    	      return "admin";
    	       }
    	     return "index";
    	   
    }
    //�����жϲ�ѯ�ķ���
    public int loginutil(String hq,int secc){
    	    int i=0;
    	   String hql="select s from "+ hq +" s where s.loginuser=? and s.password=?";
	       Session session2 = HibernateSessionFactory.getSession();
		     Query query = session2.createQuery(hql);
		     query.setString(0, user.getName());
		     query.setString(1, user.getPass());
		     Object uniqueResult = query.uniqueResult();
		     if(uniqueResult!=null){
		    	 Map<String, Object> map = ActionContext.getContext().getSession();
				 map.put("select", select);
				 map.put("users",user.getName());
				 i+=1;
		     }
    	     return i;
    }
    //��װֵջ���ṩget��set����
	public List<Juese> getList() {
		return list;
	}
	public void setList(List<Juese> list) {
		this.list = list;
	}
	public int getSelect() {
		return select;
	}
	public void setSelect(int select) {
		this.select = select;
	}
	public LoginUser getUser() {
		return user;
	}
	public void setUser(LoginUser user) {
		this.user = user;
	}

    
    
}
