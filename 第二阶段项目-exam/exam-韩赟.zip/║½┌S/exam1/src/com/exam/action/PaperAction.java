package com.exam.action;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;

import com.exam.pageinfo.HibernatePublic;
import com.exam.pageinfo.HibernateSessionFactory;
import com.exam.pojo.Juese;
import com.exam.pojo.Paper;
import com.exam.pojo.Teacher;
import com.opensymphony.xwork2.ActionSupport;

public class PaperAction extends ActionSupport {
   private HibernatePublic session=new HibernatePublic();
   private List<Paper> list;
   private List<Teacher> inform;
   private Teacher teacher;
   private Teacher teac;
   private int p;
   private int id;
   private String name;
   private String xingm;
   private String tgangwei;
   private  List<Teacher> list2;
   //�Ծ���ѯ
   public String select(){
	   list= session.getObjects("from Paper");
	   return "select";
   }
   //��ʦ��ѯ
   public String tescselect(){
	   inform= session.getObjects("from Teacher");
	   return "teacher";
   }
   //��ʦ��Ϣ����
   public String teacheradd(){
	   Juese jues= (Juese) session.select(Juese.class, new Integer(2));
	   teacher.setJid(jues.getJid());
	   session.set(teacher);
	   return "actin";
   }
   //ɾ��
   public String delete(){
	   Teacher teach = (Teacher)session.select(Teacher.class, new Integer(teacher.getTid()));
	   session.delete(teach);
	   return "actin";
   }
   //�޸Ĳ�ѯ
   public String selectid(){
//	   System.out.println(p);
	   teac= (Teacher)session.select(Teacher.class, new Integer(p));
	   return "add";
   }
   //��ʦ�޸�
   public String update(){
	   Teacher select = (Teacher)session.select(Teacher.class, new Integer(id));
//	   System.out.println(select.getTname());
//	   System.out.println(teacher.getTname());
	   select.setJuese(teacher.getJuese());
	   select.setTsex(teacher.getTsex());
	   select.setTbirthday(teacher.getTbirthday());
	   select.setTeducation(teacher.getTeducation());
	   select.setTphone(teacher.getTphone());
	   select.setTgangwei(teacher.getTgangwei());
	   select.setLoginuser(teacher.getLoginuser());
	   select.setPassword(teacher.getPassword());
	   select.setTbeizhu(teacher.getTbeizhu());
	   session.update(select);
	   return "actin";
   }
   //��������
   public String chongzhi(){
	   Teacher teac = (Teacher)session.select(Teacher.class,new Integer(teacher.getTid()));
	   teac.setPassword("123");
	   session.update(teac);
	   return "actin";
   }
   //�жϰ�ʲô��ѯ
   public String chaxun(){
	   if(!name.equals("")){
//		   System.out.println("1111111");
		   
		list2 = chazhang("loginuser",name); 
//		for (int i = 0; i < list2.size(); i++) {
//			Teacher teacher2 = list2.get(i);
//			System.out.println(teacher2.getLoginuser());
//		}
	      return "cha";
	   }else if(!xingm.equals("")){
//		   System.out.println("222222");
//		   System.out.println(xingm);
		list2 = chazhang("tname",xingm); 
		  return "cha";
	   }else if(!tgangwei.equals("")){
//		   System.out.println("3333333");
//		   System.out.println(tgangwei);
		list2 = chazhang("tgangwei",tgangwei); 
		  return "cha";
	   }
	      return "actin";
   }
   //��ѯ
   public List<Teacher> chazhang(String ziduan,String name){
	  String hql="select t from Teacher t where t."+ziduan+"=?";
	  Session session2 = HibernateSessionFactory.getSession();
	     Query query = session2.createQuery(hql);
	      query.setString(0, name);
	     List<Teacher> list = query.list();
	    return list;
   }
   public List<Paper> getList() {
	return list;
   }
   public void setList(List<Paper> list) {
	this.list = list;
   }
   public List<Teacher> getInform() {
	return inform;
   }
   public void setInform(List<Teacher> inform) {
	this.inform = inform;
   }
   public Teacher getTeacher() {
	return teacher;
   }
   public void setTeacher(Teacher teacher) {
	this.teacher = teacher;
   }
   public Teacher getTeac() {
	return teac;
   }
   public void setTeac(Teacher teac) {
	this.teac = teac;
   }
   public int getP() {
	return p;
   }
   public void setP(int p) {
	this.p = p;
   }
   public int getId() {
	return id;
   }
   public void setId(int id) {
	this.id = id;
   }
   public String getName() {
	return name;
   }
   public void setName(String name) {
	this.name = name;
   }
   public String getXingm() {
	return xingm;
   }
   public void setXingm(String xingm) {
	this.xingm = xingm;
   }
   public String getTgangwei() {
	return tgangwei;
   }
   public void setTgangwei(String tgangwei) {
	this.tgangwei = tgangwei;
   }
   public List<Teacher> getList2() {
	return list2;
   }
   public void setList2(List<Teacher> list2) {
	this.list2 = list2;
   }
    
   
}
