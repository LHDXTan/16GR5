package com.exam.fengzhuang;

public class QuesentList {
   private int suid; 
   private String sudirec;
   private String sustage;
   private String suname;
   private int num1;
   private int num2;
public int getSuid() {
	return suid;
}
public void setSuid(int suid) {
	this.suid = suid;
}
public String getSudirec() {
	return sudirec;
}
public void setSudirec(String sudirec) {
	this.sudirec = sudirec;
}
public String getSustage() {
	return sustage;
}
public void setSustage(String sustage) {
	this.sustage = sustage;
}
public String getSuname() {
	return suname;
}
public void setSuname(String suname) {
	this.suname = suname;
}
public int getNum1() {
	return num1;
}
public void setNum1(int num1) {
	this.num1 = num1;
}
public int getNum2() {
	return num2;
}
public void setNum2(int num2) {
	this.num2 = num2;
}





  
   
   
}
