/**
 * 
 */
package com.exam.fengzhuang;

/**
 * @project exam ��Ŀ����
 * @name QuestingDather ������   
 * @describe (���ڻ�ȡ��ѯ�������ķ�װ��)
 * @author Chichi ����
 * @time 2018-3-7 ����3:10:19
 */
public class QuestingDather {
   private  String sname;
   private  String stypeString;
   private  int  state;
public String getSname() {
	return sname;
}
public void setSname(String sname) {
	this.sname = sname;
}
public String getStypeString() {
	return stypeString;
}
public void setStypeString(String stypeString) {
	this.stypeString = stypeString;
}
public int getState() {
	return state;
}
public void setState(int state) {
	this.state = state;
}
@Override
public String toString() {
	return "QuestingDather [sname=" + sname + ", stypeString=" + stypeString
			+ ", state=" + state + "]";
}
   
}
