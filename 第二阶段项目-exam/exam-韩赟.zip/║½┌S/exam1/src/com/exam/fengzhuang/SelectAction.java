package com.exam.fengzhuang;

public class SelectAction {
   private String select1;
   private String select2;
public String getSelect1() {
	return select1;
}
public void setSelect1(String select1) {
	this.select1 = select1;
}
public String getSelect2() {
	return select2;
}
public void setSelect2(String select2) {
	this.select2 = select2;
}
   
}
