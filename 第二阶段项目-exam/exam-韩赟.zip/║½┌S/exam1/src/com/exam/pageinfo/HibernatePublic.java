﻿package com.exam.pageinfo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

public class HibernatePublic {
  /*
   * 添加数据
   */
	public int set(Object obj){	
		int i=0;
		Session session = HibernateSessionFactory.getSession();
		
		
		Transaction beginTransaction = session.beginTransaction();
		try {
			session.save(obj);
			beginTransaction.commit();
		} catch (Exception e) {
			beginTransaction.rollback();
			// TODO: handle exception
		}finally {
			HibernateSessionFactory.closeSession();		
		}
		i+=1;
		return i;
	}
	/*
	 * 查询数据
	 */
	public Object select(Class obj,Serializable id){
		Object clss=null;
		Session session = HibernateSessionFactory.getSession();
		Transaction beginTransaction = session.beginTransaction();
		try {
			clss =session.get(obj,id);
			beginTransaction.commit();
		} catch (Exception e) {
			beginTransaction.rollback();
			// TODO: handle exception
		}finally {
			HibernateSessionFactory.closeSession();
		}
	    return clss;	
	}
	/*
	 * 修改数据
	 */
	public int update(Object obj){
		int i=0;
		Session session = HibernateSessionFactory.getSession();
		Transaction beginTransaction = session.beginTransaction();
		try {
			session.update(obj);
			beginTransaction.commit();
		} catch (Exception e) {
			beginTransaction.rollback();
			// TODO: handle exception
		}finally {
	     HibernateSessionFactory.closeSession();
		}
		i+=1;
		return i;	
	}
	/*
	 * 删除数据
	 */
	public int delete(Object obj){
		int i=0;
		Session session = HibernateSessionFactory.getSession();
		Transaction beginTransaction = session.beginTransaction();
		try {
			session.delete(obj);
			beginTransaction.commit();
		} catch (Exception e) {
			beginTransaction.rollback();
			// TODO: handle exception
		}finally {
		 HibernateSessionFactory.closeSession();
		}
		i+=1;
		return i;
	}
	/*
	 * 查询数据
	 */
	public List getObjects(String hql) {
		Session  session = HibernateSessionFactory.getSession();
		Transaction tx = session.beginTransaction();
		List result = new ArrayList();
		try{
			result = session.createQuery(hql).list();
			tx.commit();
		}catch(Exception e){
			tx.rollback();
			e.printStackTrace();
		}finally {
			HibernateSessionFactory.closeSession();	
		}
		return result;
	}
	//查询
	public List<Object[]> createSQL(String sql){
		List<Object[]> list = null;
		Session  session = HibernateSessionFactory.getSession();
		Transaction tx = session.beginTransaction();
		list = new ArrayList();
		try{
		list = session.createSQLQuery(sql).list();
			tx.commit();
		}catch(Exception e){
			tx.rollback();
			e.printStackTrace();
		}finally {
			HibernateSessionFactory.closeSession();	
		}
		return list;
	}
}
