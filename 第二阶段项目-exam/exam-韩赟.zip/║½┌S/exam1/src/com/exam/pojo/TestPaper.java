package com.exam.pojo;

import java.util.Date;

/**
 * TestPaper entity. @author MyEclipse Persistence Tools
 */

public class TestPaper implements java.io.Serializable {

	// Fields

	private Integer tid;
	private Integer sid;
	private String tname;
	private String testType;
	private String cla;
	private Integer score;
	private Date testTime;
	private Integer stime;
	private Integer state;

	// Constructors

	/** default constructor */
	public TestPaper() {
	}

	/** minimal constructor */
	public TestPaper(Integer tid) {
		this.tid = tid;
	}

	/** full constructor */
	public TestPaper(Integer tid, Integer sid, String tname, String testType,
			String cla, Integer score, Date testTime, Integer stime,
			Integer state) {
		this.tid = tid;
		this.sid = sid;
		this.tname = tname;
		this.testType = testType;
		this.cla = cla;
		this.score = score;
		this.testTime = testTime;
		this.stime = stime;
		this.state = state;
	}

	// Property accessors

	public Integer getTid() {
		return this.tid;
	}

	public void setTid(Integer tid) {
		this.tid = tid;
	}

	public Integer getSid() {
		return this.sid;
	}

	public void setSid(Integer sid) {
		this.sid = sid;
	}

	public String getTname() {
		return this.tname;
	}

	public void setTname(String tname) {
		this.tname = tname;
	}

	public String getTestType() {
		return this.testType;
	}

	public void setTestType(String testType) {
		this.testType = testType;
	}

	public String getCla() {
		return this.cla;
	}

	public void setCla(String cla) {
		this.cla = cla;
	}

	public Integer getScore() {
		return this.score;
	}

	public void setScore(Integer score) {
		this.score = score;
	}

	public Date getTestTime() {
		return this.testTime;
	}

	public void setTestTime(Date testTime) {
		this.testTime = testTime;
	}

	public Integer getStime() {
		return this.stime;
	}

	public void setStime(Integer stime) {
		this.stime = stime;
	}

	public Integer getState() {
		return this.state;
	}

	public void setState(Integer state) {
		this.state = state;
	}

}