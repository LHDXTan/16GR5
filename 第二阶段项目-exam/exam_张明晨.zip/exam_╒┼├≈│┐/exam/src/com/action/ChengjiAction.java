package com.action;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.ServletActionContext;

import com.daoimpl.BaseDaoImpl;
import com.daoimpl.PaperDaoImpl;
import com.opensymphony.xwork2.ActionSupport;
import com.pojo.Classes;
import com.pojo.Paper;
import com.pojo.Question;
import com.pojo.Student;

public class ChengjiAction extends ActionSupport {
	private List list;
	private List<Question> questionlist;
	private Set<Question> questionset;
	private Question que;
	private Paper paper;
	private List<Paper> paperlist;
	BaseDaoImpl base = new BaseDaoImpl();
	PaperDaoImpl pdi = new PaperDaoImpl();
	HttpServletRequest request = ServletActionContext.getRequest();
	HttpServletResponse response = ServletActionContext.getResponse();
	
	//获取试卷里的试题（点击查看试卷）
	public String lookPaper(){
		paper = (Paper)base.getObjectById(Paper.class, paper.getPid());
		if(paper!=null){
			questionset = paper.getQuestion();
			list = new ArrayList();
			for(Question q:questionset ){
				list.add(q.getQid());
			}
			request.getSession().setAttribute("qidlist", list);
		}
		return "paperQuestion";
	}
	//全部试卷
	public String allChengjiPaper(){
		paperlist = base.getObjects("from Paper where pstate = 3");
		return "toAllPaper";
	}
	public List getList() {
		return list;
	}
	public void setList(List list) {
		this.list = list;
	}
	public List<Question> getQuestionlist() {
		return questionlist;
	}
	public void setQuestionlist(List<Question> questionlist) {
		this.questionlist = questionlist;
	}
	public Set<Question> getQuestionset() {
		return questionset;
	}
	public void setQuestionset(Set<Question> questionset) {
		this.questionset = questionset;
	}
	public Paper getPaper() {
		return paper;
	}
	public void setPaper(Paper paper) {
		this.paper = paper;
	}
	public List<Paper> getPaperlist() {
		return paperlist;
	}
	public void setPaperlist(List<Paper> paperlist) {
		this.paperlist = paperlist;
	}
	public Question getQue() {
		return que;
	}
	public void setQue(Question que) {
		this.que = que;
	}
	
	

}
