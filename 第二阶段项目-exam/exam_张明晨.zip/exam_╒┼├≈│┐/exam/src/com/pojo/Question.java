package com.pojo;

import java.util.HashSet;
import java.util.Set;

/**
 * Question entity. @author MyEclipse Persistence Tools
 */

public class Question implements java.io.Serializable {

	// Fields
	//考题表
	private Integer qid;	//主键
	private String type;	//类型，单选多选
	private String content;	//题目
	private String optionA;	//选项A
	private String optionB;	//选项B
	private String optionC;	//选项C
	private String optionD;	//选项D
	private String answer;	//答案
	private String hard;	//难度
	private String charpter;//章节
	private Integer suid;	//科目表id，java，3G4G
	private String qtype;
	private Subject subject;
	
	private Set<Paper> paper = new HashSet();
	

	// Constructors

	

	public Set<Paper> getPaper() {
		return paper;
	}



	public String getQtype() {
		return qtype;
	}







	public void setQtype(String qtype) {
		this.qtype = qtype;
	}







	public void setPaper(Set<Paper> paper) {
		this.paper = paper;
	}

	public Subject getSubject() {
		return subject;
	}

	public void setSubject(Subject subject) {
		this.subject = subject;
	}

	/** default constructor */
	public Question() {
	}

	/** full constructor */
	public Question(Integer qid, String type, String content, String optionA,
			String optionB, String optionC, String optionD, String hard,
			String charpter, String answer, Integer suid) {
		this.qid = qid;
		this.type = type;
		this.content = content;
		this.optionA = optionA;
		this.optionB = optionB;
		this.optionC = optionC;
		this.optionD = optionD;
		this.hard = hard;
		this.charpter = charpter;
		this.answer = answer;
		this.suid = suid;
	}

	// Property accessors

	public Integer getQid() {
		return this.qid;
	}

	public void setQid(Integer qid) {
		this.qid = qid;
	}

	public String getType() {
		return this.type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getContent() {
		return this.content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getOptionA() {
		return this.optionA;
	}

	public void setOptionA(String optionA) {
		this.optionA = optionA;
	}

	public String getOptionB() {
		return this.optionB;
	}

	public void setOptionB(String optionB) {
		this.optionB = optionB;
	}

	public String getOptionC() {
		return this.optionC;
	}

	public void setOptionC(String optionC) {
		this.optionC = optionC;
	}

	public String getOptionD() {
		return this.optionD;
	}

	public void setOptionD(String optionD) {
		this.optionD = optionD;
	}

	public String getHard() {
		return this.hard;
	}

	public void setHard(String hard) {
		this.hard = hard;
	}

	public String getCharpter() {
		return this.charpter;
	}

	public void setCharpter(String charpter) {
		this.charpter = charpter;
	}

	public String getAnswer() {
		return this.answer;
	}

	public void setAnswer(String answer) {
		this.answer = answer;
	}

	public Integer getSuid() {
		return this.suid;
	}

	public void setSuid(Integer suid) {
		this.suid = suid;
	}

}