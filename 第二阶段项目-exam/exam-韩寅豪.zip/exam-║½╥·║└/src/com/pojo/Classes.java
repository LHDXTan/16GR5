package com.pojo;

import java.util.HashSet;
import java.util.Set;

/**
 * Classes entity. @author MyEclipse Persistence Tools
 */

public class Classes implements java.io.Serializable {

	// Fields

	private Integer cid;
	private String classname;
	private Set<Student> students = new HashSet();
	

	// Constructors

	public Set<Student> getStudents() {
		return students;
	}

	public void setStudents(Set<Student> students) {
		this.students = students;
	}

	/** default constructor */
	public Classes() {
	}

	/** minimal constructor */
	public Classes(Integer cid) {
		this.cid = cid;
	}

	/** full constructor */
	public Classes(Integer cid, String classname) {
		this.cid = cid;
		this.classname = classname;
	}

	// Property accessors

	public Integer getCid() {
		return this.cid;
	}

	public void setCid(Integer cid) {
		this.cid = cid;
	}

	public String getClassname() {
		return this.classname;
	}

	public void setClassname(String classname) {
		this.classname = classname;
	}

}