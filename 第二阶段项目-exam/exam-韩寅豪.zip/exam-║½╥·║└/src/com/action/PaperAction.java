package com.action;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONArray;

import org.apache.struts2.ServletActionContext;

import com.beans.PageBean;
import com.beans.RandomPaper;
import com.daoimpl.BaseDaoImpl;
import com.daoimpl.PaperDaoImpl;
import com.opensymphony.xwork2.ActionSupport;
import com.pojo.Classes;
import com.pojo.Paper;
import com.pojo.Paperinfo;
import com.pojo.Question;
import com.pojo.Student;
import com.pojo.Subject;

public class PaperAction extends ActionSupport {
	private PageBean pb;
	private List<Paper> paperlist;
	private List<Question> questionlist;
	private List<Paperinfo> pilist;
	private List<Classes> clalist;
	private Student stu;
	private Classes cla;
	private Paper paper;
	private Question que;
	private Paperinfo info;
	private RandomPaper ran;
	private Set<Question> questionset;
	private List list;
	private String str;
	private String kemu;
	private String[] box;
	private String ing;
	private String examtime;
	BaseDaoImpl base = new BaseDaoImpl();
	PaperDaoImpl pdi = new PaperDaoImpl();
	HttpServletRequest request = ServletActionContext.getRequest();
	HttpServletResponse response = ServletActionContext.getResponse();
	
	//结束考试
	public String endExam(){
		if(paper!=null){
			paper = (Paper) base.getObjectById(Paper.class, paper.getPid());
			paper.setPstate(3);
			base.update(paper);
		}
		return "toAllPaper";
	}
	
	//开始考试
	public String addStartExam() throws IOException, ParseException{
		response.setContentType("text;charset=UTF-8");
		PrintWriter out = response.getWriter();
		
		//获取现在的时间
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"); 
		Date day = new Date();
	    String nowtime = df.format(day);	    
	    //判断开考时间是否正确，返回值为2，即不正确
	    int x = pdi.compare_date(examtime, nowtime);
	    if(x==2){
	    	out.print(0);
	    } else {
			int pid = Integer.parseInt(request.getSession().getAttribute("startExamPid").toString());
			paper =(Paper) base.getObjectById(Paper.class, pid);
			paper.setExamtime(examtime);
			Classes c = (Classes)base.getObjectById(Classes.class, cla.getCid());
			paper.setClassname(c.getClassname());
			if(x==3){
				paper.setPstate(2);
			}
			int flag = base.update(paper);
			out.print(flag);
	    }
		return null;
	}
	
	public String toPreStartExam(){
		if(paper!=null){
			request.getSession().setAttribute("startExamPid", paper.getPid());
		}
		clalist =  base.getObjects("from Classes");
		return "toPreStartExam";
	}
	
	//删除试卷
	public String delPaper(){
		if(paper!=null){
			paper = (Paper)base.getObjectById(Paper.class, paper.getPid());
			base.delete(paper);
		}
		return "toAllPaper";
	}
	
	//条件查询
	public String selectPaper(){
		StringBuffer sb = new StringBuffer("");
		str=base.fangXiang();
		int up = 1;		//默认显示第一页
		if(pb!=null){
			up = pb.getP();
			if(up>pb.getPagetotal()){
				up = pb.getPagetotal();
			}
		}	
		if(request.getSession().getAttribute("rand")==null){
			if(ran!=null){
				request.getSession().setAttribute("rand", ran);
				pb = pdi.selectPaper(ran, up);
			} else {
				pb = pdi.getAllPaper(up);
			}	
		} else {
			if(ran==null){
				ran = (RandomPaper)request.getSession().getAttribute("rand");
				pb = pdi.selectPaper(ran, up);
			} else {
				request.getSession().setAttribute("rand", ran);
				pb = pdi.selectPaper(ran, up);
			}		
		}
		paperlist = pb.getPaperlist();
		return "toPaper";
	}
	
	//上一页下一页
	public String ud() throws IOException{
		response.setContentType("text;charset=UTF-8");
		PrintWriter out = response.getWriter();
		
		if(box!=null && box.length!=0){
			pdi.choicePaper(box);
		}
		
		int suid = 0;
		if(request.getSession().getAttribute("ajaxsuid")!=null){
			suid = Integer.parseInt(request.getSession().getAttribute("ajaxsuid").toString());
		}
		int up = 1;		//默认显示第一页
		if(pb!=null){
			up = pb.getP();
			if(up>pb.getPagetotal()){
				up = pb.getPagetotal();
			}
			pb = pdi.getAllPentQuestion(suid,up);
			questionlist = pb.getQuestionlist();
			if(questionlist.size()!=0){
				JSONArray json = pdi.choicePaperJson(questionlist);
				String js = json.toString();
				js = (String) js.subSequence(2, js.length());
				js = "[{\"p\":"+pb.getP()+",\"pagetotal\":"+pb.getPagetotal()+",\"num\":"+paper.getPtotalNum()+","+js;
				out.print(js);
			}  else {
				out.print(0);
			}
		}
		return null;
	}
	
	//首页尾页
	public String oe() throws IOException{
		response.setContentType("text;charset=UTF-8");
		PrintWriter out = response.getWriter();
		if(box!=null && box.length!=0){
			pdi.choicePaper(box);
		}
		int suid = 0;
		if(request.getSession().getAttribute("ajaxsuid")!=null){
			suid = Integer.parseInt(request.getSession().getAttribute("ajaxsuid").toString());
		}
		int up = 1;		//默认显示第一页
		if(pb!=null){
			up = pb.getP();
			if(up>pb.getPagetotal()){
				up = pb.getPagetotal();
			}
		}
		pb = pdi.getAllPentQuestion(suid,up);
		questionlist = pb.getQuestionlist();
		if(questionlist.size()!=0){
			JSONArray json = pdi.choicePaperJson(questionlist);
			String js = json.toString();
			js = (String) js.subSequence(2, js.length());
			js = "[{\"p\":"+pb.getP()+",\"pagetotal\":"+pb.getPagetotal()+","+js;
			out.print(js);
		}  else {
			out.print(0);
		}
		return null;
	}
	
	//选题组卷
	public String addChoicePaper() throws IOException{
		response.setContentType("text;charset=UTF-8");
		PrintWriter out = response.getWriter();
		ran.setKemu(kemu);
		//获取到科目表的suid
		int suid = base.getSuid(ran);
		paper.setPtype("笔试题");
		paper.setSuname(kemu);
		paper.setPstate(1);	
//		int i2 = Integer.parseInt(box[0].toString());
		List alllist = pdi.choicePaper(box);
		if(alllist.size()!=0){
			for(int i=0;i<alllist.size();i++){
				Question question = (Question) base.getObjectById(Question.class, Integer.parseInt(alllist.get(i).toString()));
				paper.getQuestion().add(question);
			}
		}
		int flag = base.add(paper);
		if(flag==1){
			request.getSession().removeAttribute("addChoicePaperQid");
			out.print(1);
		} else {
			out.print(0);
		}
		return null;
	}
	
	//下拉框改变事件，修改表格中的题
	public String changeQuestion() throws IOException{
		response.setContentType("text;charset=UTF-8");
		PrintWriter out = response.getWriter();
		if(request.getSession().getAttribute("ajaxsuid")!=null){
			request.getSession().removeAttribute("ajaxsuid");
		}
		if(ran.getKemu()!="请选择"){
			//获取到科目表的suid，用以查询到所有的题目
			int suid = base.getSuid(ran);
			request.getSession().setAttribute("ajaxsuid", suid);
			pb = pdi.getAllPentQuestion(suid, 1);
			questionlist = pb.getQuestionlist();
			if(questionlist.size()!=0){
				JSONArray json = pdi.choicePaperJson(questionlist);
				String js = json.toString();
				js = (String) js.subSequence(2, js.length());
				js = "[{\"p\":"+pb.getP()+",\"pagetotal\":"+pb.getPagetotal()+","+js;
				out.print(js);
			} else {
				out.print(0);
			}
		}
		return null;
	}
	
	//去选题组卷页面（点击选题组卷）
	public String choicePaper(){
		StringBuffer sb = new StringBuffer("");
		str=base.fangXiang();
		pb = pdi.getAllPentQuestion(0,1);
		questionlist = pb.getQuestionlist();
		request.setAttribute("p1", pb.getP());
		request.setAttribute("p2", pb.getPagetotal());
		return "toAddChoicePaper";
	}
	
	//随机创建笔试试卷
	public String addRandomPaper() throws IOException{
		response.setContentType("text;charset=UTF-8");
		PrintWriter out = response.getWriter();
		//ran存放的是难度题数，方向等
		ran.setKemu(kemu);
		//获取到科目表的suid，用以查询到所有的题目
		int suid = base.getSuid(ran);
		//获取到全部难度的题List
		List alllist = base.getPenQuestions(suid);
		/*
		 * 通过单选双选所有难度的题数等信息（ran）和获取到的所有难度的题alllist
		 * 调用方法，随机获取题，返回nublist，里面存放6个list，分别对应单选双选的三个难度
		 * */
		List nublist = pdi.getRandomListQuestion(alllist, ran);
		List list = new ArrayList();
		//修改试卷状态为未开考（我数据库里的试卷状态是pstate）
		paper.setPstate(1);
		paper.setPtype("笔试题");
		paper.setSuname(kemu);
		//遍历随机获取到的所有题号，添加到到试卷paper里
		for(int i=0;i<nublist.size();i++){
			list = (List)nublist.get(i);
			for(int j=0;j<list.size();j++){
				Question question = (Question) base.getObjectById(Question.class, Integer.parseInt(list.get(j).toString()));
				paper.getQuestion().add(question);
			}
		}
		//新建试卷，返回1为创建成功，否则返回0
		int flag = base.add(paper);
		//ajax返回值
		if(flag==1){
			out.print(1);
		} else {
			out.print(0);
		}
		return null;
	}
	
	//去随机组卷页面（点击随机组卷）
	public String randomPaper(){
		StringBuffer sb = new StringBuffer("");
		str=base.fangXiang();
		return "toAddRandomPaper";
	}
	
	//替换试题
	public String updQuestion() throws IOException{
		response.setContentType("text;charset=UTF-8");
		PrintWriter out = response.getWriter();
		Paperinfo p = new Paperinfo();
		int qid = Integer.parseInt(request.getSession().getAttribute("qid").toString());
		int pid = Integer.parseInt(request.getSession().getAttribute("pid").toString());
		pilist = base.getObjects("from Paperinfo where qid='"+qid+"' and pid='"+pid+"'");
		if(pilist!=null){
			p = pilist.get(0);
			p.setQid(que.getQid());
			int flag = base.update(p);
			if(flag==1){
				out.print(1);
			} else {
				out.print(0);
			}
		}
		return null;
	}
	//替换试卷试题（点击替换按钮）
	public String toUpdQuestion(){
		request.getSession().setAttribute("qid", que.getQid());
		request.getSession().setAttribute("pid", paper.getPid());
		list = (List) request.getSession().getAttribute("qidlist");
		questionlist = base.getObjects("from Question where suid = '"+que.getSuid()+"'");
		return "updQuestion";
	}
	
	//获取试卷里的试题（点击查看试卷）
	public String lookPaper(){
		//清空session
		request.getSession().removeAttribute("ing");
		//ing不为空并且等于1，存入session中
		if(ing!=null && ing=="1"){
			request.getSession().setAttribute("ing", "1");
		}
		paper = (Paper)base.getObjectById(Paper.class, paper.getPid());
		if(paper!=null){
			questionset = paper.getQuestion();
			list = new ArrayList();
			for(Question q:questionset ){
				list.add(q.getQid());
			}
			request.getSession().setAttribute("qidlist", list);
		}
		return "paperQuestion";
	}
	
	//全部的试卷信息
	public String paperAll(){
		if(request.getSession().getAttribute("rand")!=null){
			request.getSession().removeAttribute("rand");
		}
		StringBuffer sb = new StringBuffer("");
		str=base.fangXiang();
		int up = 1;		//默认显示第一页
		if(pb!=null){
			up = pb.getP();
			if(up>pb.getPagetotal()){
				up = pb.getPagetotal();
			}
		}
		pb = pdi.getAllPaper(up);
		paperlist = pb.getPaperlist();
		return "toPaper";
	}

	public List<Paper> getPaperlist() {
		return paperlist;
	}

	public void setPaperlist(List<Paper> paperlist) {
		this.paperlist = paperlist;
	}

	public Paper getPaper() {
		return paper;
	}

	public void setPaper(Paper paper) {
		this.paper = paper;
	}

	public List<Question> getQuestionlist() {
		return questionlist;
	}

	public void setQuestionlist(List<Question> questionlist) {
		this.questionlist = questionlist;
	}

	public Question getQue() {
		return que;
	}

	public void setQue(Question que) {
		this.que = que;
	}

	public Set<Question> getQuestionset() {
		return questionset;
	}

	public void setQuestionset(Set<Question> questionset) {
		this.questionset = questionset;
	}
	public Paperinfo getInfo() {
		return info;
	}
	public void setInfo(Paperinfo info) {
		this.info = info;
	}

	public List getList() {
		return list;
	}

	public void setList(List list) {
		this.list = list;
	}

	public String getStr() {
		return str;
	}

	public void setStr(String str) {
		this.str = str;
	}

	public RandomPaper getRan() {
		return ran;
	}

	public void setRan(RandomPaper ran) {
		this.ran = ran;
	}

	public String getKemu() {
		return kemu;
	}

	public void setKemu(String kemu) {
		this.kemu = kemu;
	}

	public String[] getBox() {
		return box;
	}

	public void setBox(String[] box) {
		this.box = box;
	}

	public PageBean getPb() {
		return pb;
	}

	public void setPb(PageBean pb) {
		this.pb = pb;
	}

	public String getIng() {
		return ing;
	}

	public void setIng(String ing) {
		this.ing = ing;
	}

	public List<Paperinfo> getPilist() {
		return pilist;
	}

	public void setPilist(List<Paperinfo> pilist) {
		this.pilist = pilist;
	}

	public Student getStu() {
		return stu;
	}

	public void setStu(Student stu) {
		this.stu = stu;
	}

	public Classes getCla() {
		return cla;
	}

	public void setCla(Classes cla) {
		this.cla = cla;
	}

	public List<Classes> getClalist() {
		return clalist;
	}

	public void setClalist(List<Classes> clalist) {
		this.clalist = clalist;
	}

	public String getExamtime() {
		return examtime;
	}

	public void setExamtime(String examtime) {
		this.examtime = examtime;
	}





}
