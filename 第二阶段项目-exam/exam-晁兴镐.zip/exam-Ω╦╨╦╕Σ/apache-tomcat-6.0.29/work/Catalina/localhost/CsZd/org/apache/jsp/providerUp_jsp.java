package org.apache.jsp;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import java.util.*;

public final class providerUp_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static final JspFactory _jspxFactory = JspFactory.getDefaultFactory();

  private static java.util.List _jspx_dependants;

  private javax.el.ExpressionFactory _el_expressionfactory;
  private org.apache.AnnotationProcessor _jsp_annotationprocessor;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspInit() {
    _el_expressionfactory = _jspxFactory.getJspApplicationContext(getServletConfig().getServletContext()).getExpressionFactory();
    _jsp_annotationprocessor = (org.apache.AnnotationProcessor) getServletConfig().getServletContext().getAttribute(org.apache.AnnotationProcessor.class.getName());
  }

  public void _jspDestroy() {
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      response.setContentType("text/html;charset=GBK");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write('\r');
      out.write('\n');

String path = request.getContextPath();
String basePath = request.getScheme()+"://"+request.getServerName()+":"+request.getServerPort()+path+"/";

      out.write("\r\n");
      out.write("\r\n");
      out.write("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">\r\n");
      out.write("<html>\r\n");
      out.write("  <head>\r\n");
      out.write("    <base href=\"");
      out.print(basePath);
      out.write("\">\r\n");
      out.write("    \r\n");
      out.write("    <title>My JSP 'providerAdd.jsp' starting page</title>\r\n");
      out.write("    \r\n");
      out.write("\t<meta http-equiv=\"pragma\" content=\"no-cache\">\r\n");
      out.write("\t<meta http-equiv=\"cache-control\" content=\"no-cache\">\r\n");
      out.write("\t<meta http-equiv=\"expires\" content=\"0\">    \r\n");
      out.write("\t<meta http-equiv=\"keywords\" content=\"keyword1,keyword2,keyword3\">\r\n");
      out.write("\t<meta http-equiv=\"description\" content=\"This is my page\">\r\n");
      out.write("\t<!--\r\n");
      out.write("\t<link rel=\"stylesheet\" type=\"text/css\" href=\"styles.css\">\r\n");
      out.write("\t-->\r\n");
      out.write("<link type=\"text/css\" rel=\"stylesheet\" href=\"css/style.css\" />\r\n");
      out.write("<script type=\"text/javascript\">\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("function up()\r\n");
      out.write("{\r\n");
      out.write(" if(confirm('确定要执行修改操作吗?')) \r\n");
      out.write("    { \r\n");
      out.write("    document.getElementById(\"q\").value=\"xiu\";\r\n");
      out.write("        return true; \r\n");
      out.write("    } \r\n");
      out.write("    history.back();\r\n");
      out.write("    return false; \r\n");
      out.write("\t}\r\n");
      out.write("function del()\r\n");
      out.write("{\r\n");
      out.write(" if(confirm('确定要执行删除操作吗?')) \r\n");
      out.write("    { \r\n");
      out.write("    document.getElementById(\"q\").value=\"del\";\r\n");
      out.write("        return true; \r\n");
      out.write("    } \r\n");
      out.write("    history.back();\r\n");
      out.write("    return false; \r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("}\r\n");
      out.write("</script>\r\n");
      out.write("  </head>\r\n");
      out.write("  \r\n");
      out.write("  <body>\r\n");
      out.write("<div class=\"main\">\r\n");
      out.write("\t<div class=\"optitle clearfix\">\r\n");
      out.write("\t\t<div class=\"title\">供应商管理&gt;&gt;</div>\r\n");
      out.write("\t</div>\r\n");
      out.write("\t<form id=\"form1\" name=\"form1\" method=\"post\" action=\"Gy\" onsubmit=\"return checkit();\">\r\n");
      out.write("\t<input type=\"hidden\" name=\"cmd\" id=\"q\">\r\n");
      out.write("\t\t<div class=\"content\">\r\n");
      out.write("\t\t<font color=\"red\"></font>\r\n");
      out.write("<input name=\"flag\" value=\"doAdd\" type=\"hidden\">\r\n");
      out.write("\t\t\t<table class=\"box\">\r\n");
      out.write("\r\n");
      out.write("\t\t\t<tbody><tr>\r\n");
      out.write("\t\t\t\t\t<td class=\"field\">供应商编号：</td>\r\n");
      out.write("\t\t\t\t\t<td><input name=\"proId\" id=\"textfield\" class=\"text\" type=\"text\" value=\"");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${pro.providerId}", java.lang.String.class, (PageContext)_jspx_page_context, null, false));
      out.write("\"/> <font color=\"red\">*</font></td>\r\n");
      out.write("\t\t\t\t</tr>\r\n");
      out.write("\t\t\t\t<tr>\r\n");
      out.write("\t\t\t\t\t<td class=\"field\">供应商名称：</td>\r\n");
      out.write("\t\t\t\t\t<td><input name=\"proName\" id=\"textfield2\"  class=\"text\" type=\"text\" value=\"");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${pro.providerName}", java.lang.String.class, (PageContext)_jspx_page_context, null, false));
      out.write("\"/> <font color=\"red\">*</font></td>\r\n");
      out.write("\r\n");
      out.write("\t\t\t\t</tr>\r\n");
      out.write("\t\t\t<tr>\r\n");
      out.write("\t\t\t\t\t<td class=\"field\">供应商描述：</td>\r\n");
      out.write("\t\t\t\t\t<td><textarea name=\"proDesc\" id=\"textarea\" cols=\"45\" rows=\"5\" >");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${pro.providerDetail}", java.lang.String.class, (PageContext)_jspx_page_context, null, false));
      out.write("</textarea></td>\r\n");
      out.write("\t\t\t\t</tr>\r\n");
      out.write("\t\t\t\t<tr>\r\n");
      out.write("\t\t\t\t\t<td class=\"field\">供应商联系：</td>\r\n");
      out.write("\r\n");
      out.write("\t\t\t\t\t<td><input name=\"contact\" id=\"textfield2\" class=\"text\" type=\"text\" value=\"");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${pro.contact}", java.lang.String.class, (PageContext)_jspx_page_context, null, false));
      out.write("\"/></td>\r\n");
      out.write("\t\t\t\t</tr>\r\n");
      out.write("\t\t\t\t<tr>\r\n");
      out.write("\t\t\t\t\t<td class=\"field\">供应商电话：</td>\r\n");
      out.write("\t\t\t\t\t<td><input name=\"phone\" id=\"textfield2\"  class=\"text\" type=\"text\" value=\"");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${pro.telephone}", java.lang.String.class, (PageContext)_jspx_page_context, null, false));
      out.write("\"/></td>\r\n");
      out.write("\t\t\t\t</tr>\r\n");
      out.write("\t\t\t\t<tr>\r\n");
      out.write("\t\t\t\t\t<td class=\"field\">供应商传真：</td>\r\n");
      out.write("\r\n");
      out.write("\t\t\t\t\t<td><input name=\"fax\" id=\"textfield2\" class=\"text\" type=\"text\" value=\"");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${pro.facsimile}", java.lang.String.class, (PageContext)_jspx_page_context, null, false));
      out.write("\"/></td>\r\n");
      out.write("\t\t\t\t</tr>\r\n");
      out.write("\t\t\t\t<tr>\r\n");
      out.write("\t\t\t\t\t<td class=\"field\">供应商地址：</td>\r\n");
      out.write("\t\t\t\t\t<td><input name=\"address\" id=\"textfield2\"  class=\"text\" type=\"text\" value=\"");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${pro.address}", java.lang.String.class, (PageContext)_jspx_page_context, null, false));
      out.write("\"/></td>\r\n");
      out.write("\t\t\t\t</tr>\r\n");
      out.write("\t\t\t</tbody></table>\r\n");
      out.write("\t\t</div>\r\n");
      out.write("\r\n");
      out.write("\t\t<div class=\"buttons\">\r\n");
      out.write("\t\t\t<input name=\"button\" id=\"button\" value=\"删除\" class=\"input-button\" type=\"submit\" onclick=\"del()\"> \r\n");
      out.write("\t\t\t<input type=\"submit\" name=\"xiu\" id=\"button\" value=\"修改\" class=\"input-button\" onclick=\"up()\"/>\r\n");
      out.write("\t\t\t<input name=\"button\" id=\"button\" onclick=\"history.back()\" value=\"返回\" class=\"input-button\" type=\"button\"> \r\n");
      out.write("\t\t</div>\r\n");
      out.write("\t</form>\r\n");
      out.write("</div>\r\n");
      out.write("</body>\r\n");
      out.write("</html>\r\n");
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          try { out.clearBuffer(); } catch (java.io.IOException e) {}
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
