package org.apache.jsp;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import java.util.*;
import com.cszd.Vo.*;

public final class userAdmin_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static final JspFactory _jspxFactory = JspFactory.getDefaultFactory();

  private static java.util.List _jspx_dependants;

  private javax.el.ExpressionFactory _el_expressionfactory;
  private org.apache.AnnotationProcessor _jsp_annotationprocessor;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspInit() {
    _el_expressionfactory = _jspxFactory.getJspApplicationContext(getServletConfig().getServletContext()).getExpressionFactory();
    _jsp_annotationprocessor = (org.apache.AnnotationProcessor) getServletConfig().getServletContext().getAttribute(org.apache.AnnotationProcessor.class.getName());
  }

  public void _jspDestroy() {
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      response.setContentType("text/html;charset=GBK");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("\r\n");
      out.write("\r\n");

String path = request.getContextPath();
String basePath = request.getScheme()+"://"+request.getServerName()+":"+request.getServerPort()+path+"/";

      out.write("\r\n");
      out.write("\r\n");
      out.write("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">\r\n");
      out.write("<html>\r\n");
      out.write("  <head>\r\n");
      out.write("    <base href=\"");
      out.print(basePath);
      out.write("\">\r\n");
      out.write("    \r\n");
      out.write("    <title>My JSP 'userAdmin.jsp' starting page</title>\r\n");
      out.write("    \r\n");
      out.write("\t<meta http-equiv=\"pragma\" content=\"no-cache\">\r\n");
      out.write("\t<meta http-equiv=\"cache-control\" content=\"no-cache\">\r\n");
      out.write("\t<meta http-equiv=\"expires\" content=\"0\">    \r\n");
      out.write("\t<meta http-equiv=\"keywords\" content=\"keyword1,keyword2,keyword3\">\r\n");
      out.write("\t<meta http-equiv=\"description\" content=\"This is my page\">\r\n");
      out.write("\t<!--\r\n");
      out.write("\t<link rel=\"stylesheet\" type=\"text/css\" href=\"styles.css\">\r\n");
      out.write("\t-->\r\n");
      out.write("<link type=\"text/css\" rel=\"stylesheet\" href=\"css/style.css\">\r\n");
      out.write("<script type=\"text/javascript\">\r\n");
      out.write("function a()\r\n");
      out.write("{\r\n");
      out.write("\twindow.location.href = \"Yh?cmd=sc\";\r\n");
      out.write("}\r\n");
      out.write("</script>\r\n");
      out.write("  </head>\r\n");
      out.write("  \r\n");
      out.write("  <body>\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("<div class=\"menu\">\r\n");
      out.write("\r\n");
      out.write("<table>\r\n");
      out.write("<tbody><tr><td><form method=\"post\" action=\"Yh\">\r\n");
      out.write("<input type=\"hidden\" name=\"cmd\" value=\"cha\">\r\n");
      out.write("\r\n");
      out.write("用户名称：<input name=\"userName\" class=\"input-text\" type=\"text\" >&nbsp;&nbsp;&nbsp;&nbsp; <input value=\"查 询\" type=\"submit\">\r\n");
      out.write("</form></td></tr>\r\n");
      out.write("</tbody></table>\r\n");
      out.write("</div>\r\n");
      out.write("<div class=\"main\">\r\n");
      out.write("\r\n");
      out.write("<div class=\"optitle clearfix\">\r\n");
      out.write("<em><input value=\"添加数据\" class=\"input-button\" onclick=\"window.location='userAdd.jsp'\" type=\"button\"></em>\r\n");
      out.write("\t\t<div class=\"title\">用户管理&gt;&gt;</div>\r\n");
      out.write("\t</div>\r\n");
      out.write("\t<div class=\"content\">\r\n");
      out.write("<table class=\"list\">\r\n");
      out.write("  <tbody><tr>\r\n");
      out.write("    <td width=\"70\" height=\"29\"><div class=\"STYLE1\" align=\"center\">编号</div></td>\r\n");
      out.write("    <td width=\"80\"><div class=\"STYLE1\" align=\"center\">用户名称</div></td>\r\n");
      out.write("    <td width=\"100\"><div class=\"STYLE1\" align=\"center\">性别</div></td>\r\n");
      out.write("    <td width=\"100\"><div class=\"STYLE1\" align=\"center\">年龄</div></td>\r\n");
      out.write("\r\n");
      out.write("    <td width=\"150\"><div class=\"STYLE1\" align=\"center\">电话 </div></td>\r\n");
      out.write("    <td width=\"150\"><div class=\"STYLE1\" align=\"center\">地址 </div></td>\r\n");
      out.write("    <td width=\"150\"><div class=\"STYLE1\" align=\"center\">权限 </div></td>\r\n");
      out.write("  </tr>\r\n");
      out.write("  ");

	PageBean pb=(PageBean)request.getAttribute("pb");
	List tacts=pb.getData();
	for(int i=0;i<tacts.size();i++){
		UserShow u=(UserShow)tacts.get(i);
 
      out.write("\r\n");
      out.write("  <tr>\r\n");
      out.write("    <td height=\"23\"><span class=\"STYLE1\">");
      out.print(u.getUserId() );
      out.write("</span></td>\r\n");
      out.write("    <td><span class=\"STYLE1\" ><a href=\"Yh?cmd=sc&s=");
      out.print(u.getUserName() );
      out.write("\" onclick=\"\" name=\"s\" >");
      out.print(u.getUserName() );
      out.write("</a></span></td>\r\n");
      out.write("\r\n");
      out.write("    <td><span class=\"STYLE1\">\r\n");
      out.write("    \t");
      out.print(u.getUserSex() );
      out.write("\r\n");
      out.write("    </span></td>\r\n");
      out.write("    <td><span class=\"STYLE1\">");
      out.print(u.getUserAge() );
      out.write("</span></td>\r\n");
      out.write("    <td><span class=\"STYLE1\">");
      out.print(u.getTelephone() );
      out.write("</span></td>\r\n");
      out.write("    <td><span class=\"STYLE1\">");
      out.print(u.getAddress() );
      out.write("</span></td>\r\n");
      out.write("    <td><span class=\"STYLE1\">\r\n");
      out.write("    ");
      out.print(u.getType() );
      out.write("\r\n");
      out.write("    </span></td>\r\n");
      out.write("\r\n");
      out.write("  </tr>\r\n");
      out.write("  ");
}
      out.write("\r\n");
      out.write("</tbody></table>\r\n");
      out.write("<center>\r\n");
      out.write("共");
      out.print(pb.getCount());
      out.write("条记录，\r\n");
      out.write("第");
      out.print(pb.getP());
      out.write('页');
      out.write('/');
      out.write('共');
      out.print(pb.getPagetotal());
      out.write("页&nbsp;\r\n");
      out.write("<a href=\"Yh?cmd=all&p=1\">首页</a>\r\n");
      out.write("<a href=\"Yh?cmd=all&p=");
      out.print(pb.getP()-1);
      out.write("\">上一页</a>\r\n");
      out.write("<a href=\"Yh?cmd=all&p=");
      out.print(pb.getP()+1);
      out.write("\">下一页</a>\r\n");
      out.write("<a href=\"Yh?cmd=all&p=");
      out.print(pb.getPagetotal());
      out.write("\">尾页</a>&nbsp;\r\n");
      out.write("跳到第:\r\n");
      out.write("<select id=\"secpage\" onchange=toPage(this.value)>\r\n");
      out.write("\t<script language=\"javascript\">\r\n");
      out.write("\t\tfunction toPage(a){\r\n");
      out.write("\t\t\tlocation=\"Yh?cmd=all&p=\"+a;\r\n");
      out.write("\t\t}\r\n");
      out.write("\t\tfor(i=1;i<=");
      out.print(pb.getPagetotal());
      out.write(";i++){\r\n");
      out.write("\t\t\tdocument.write(\"<option value=\"+i+\">\"+i+\"</option>\");\r\n");
      out.write("\t\t}\r\n");
      out.write("\t\tdocument.getElementById(\"secpage\").value=");
      out.print(pb.getP());
      out.write("\r\n");
      out.write("\t</script>\r\n");
      out.write("</select>页\r\n");
      out.write("</center>\r\n");
      out.write("</div>\r\n");
      out.write("</div>\r\n");
      out.write("</body>\r\n");
      out.write("</html>\r\n");
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          try { out.clearBuffer(); } catch (java.io.IOException e) {}
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
