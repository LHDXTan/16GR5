package org.apache.jsp;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import java.util.*;
import com.cszd.Vo.*;

public final class admin_005fbill_005flist_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static final JspFactory _jspxFactory = JspFactory.getDefaultFactory();

  private static java.util.List _jspx_dependants;

  private javax.el.ExpressionFactory _el_expressionfactory;
  private org.apache.AnnotationProcessor _jsp_annotationprocessor;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspInit() {
    _el_expressionfactory = _jspxFactory.getJspApplicationContext(getServletConfig().getServletContext()).getExpressionFactory();
    _jsp_annotationprocessor = (org.apache.AnnotationProcessor) getServletConfig().getServletContext().getAttribute(org.apache.AnnotationProcessor.class.getName());
  }

  public void _jspDestroy() {
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      response.setContentType("text/html;charset=GBK");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("\r\n");
      out.write("\r\n");

String path = request.getContextPath();
String basePath = request.getScheme()+"://"+request.getServerName()+":"+request.getServerPort()+path+"/";

      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">\r\n");
      out.write("<html>\r\n");
      out.write("  <head>\r\n");
      out.write("    <base href=\"");
      out.print(basePath);
      out.write("\">\r\n");
      out.write("    \r\n");
      out.write("    <title>My JSP 'admin_bill_list.jsp' starting page</title>\r\n");
      out.write("    \r\n");
      out.write("\t<meta http-equiv=\"pragma\" content=\"no-cache\">\r\n");
      out.write("\t<meta http-equiv=\"cache-control\" content=\"no-cache\">\r\n");
      out.write("\t<meta http-equiv=\"expires\" content=\"0\">    \r\n");
      out.write("\t<meta http-equiv=\"keywords\" content=\"keyword1,keyword2,keyword3\">\r\n");
      out.write("\t<meta http-equiv=\"description\" content=\"This is my page\">\r\n");
      out.write("\t<!--\r\n");
      out.write("\t<link rel=\"stylesheet\" type=\"text/css\" href=\"styles.css\">\r\n");
      out.write("\t-->\r\n");
      out.write("\t<link type=\"text/css\" rel=\"stylesheet\" href=\"css/style.css\" />\r\n");
      out.write("\r\n");
      out.write("  </head>\r\n");
      out.write("  \r\n");
      out.write(" <script language=\"javascript\">\r\n");
      out.write("function a() {\r\n");
      out.write("window.location.href = \"Ac?cmd=all\";\r\n");
      out.write("}\r\n");
      out.write("</script>\r\n");
      out.write("  <body>\r\n");
      out.write("   <div class=\"menu\">\r\n");
      out.write("\t<form method=\"post\" action=\"Ac\">\r\n");
      out.write("\t<input name=\"cmd\" value=\"cha\" type=\"hidden\">\r\n");
      out.write("\t\t商品名称：<input type=\"text\" name=\"productName\" class=\"input-text\" />&nbsp;&nbsp;&nbsp;&nbsp;\r\n");
      out.write("\t\t是否付款：<select name=\"payStatus\">\r\n");
      out.write("\t\t\t<option value=\"\">请选择</option>\r\n");
      out.write("\t\t\t<option value=\"1\">已付款</option>\r\n");
      out.write("\t\t\t<option value=\"0\">未付款</option>\r\n");
      out.write("\t\t</select>&nbsp;&nbsp;&nbsp;&nbsp;\r\n");
      out.write("\t\t<input type=\"submit\" name=\"submit\" value=\"组合查询\" class=\"button\" />\r\n");
      out.write("\t</form>\r\n");
      out.write("</div>\r\n");
      out.write("\r\n");
      out.write("\t\r\n");
      out.write("<div class=\"main\">\r\n");
      out.write("\t<div class=\"optitle clearfix\">\r\n");
      out.write("\t\t<em><input type=\"button\" name=\"button\" value=\"添加数据\" class=\"input-button\" onclick=\"location.href='Ac?cmd=add1'\" /></em>\r\n");
      out.write("\t\t<div class=\"title\">账单管理&gt;&gt;</div>\r\n");
      out.write("\t</div>\r\n");
      out.write("\t<div class=\"content\">\r\n");
      out.write("\t\t<table class=\"list\">\r\n");
      out.write("\t\t\t<tr>\r\n");
      out.write("\t\t\t\t<td>账单编号</td>\r\n");
      out.write("\t\t\t\t<td>商品名称</td>\r\n");
      out.write("\t\t\t\t<td>商品数量</td>\r\n");
      out.write("\t\t\t\t<td>交易金额</td>\r\n");
      out.write("\t\t\t\t<td>是否付款</td>\r\n");
      out.write("\t\t\t\t<td>供应商名称</td>\r\n");
      out.write("\t\t\t\t<td>商品描述</td>\r\n");
      out.write("\t\t\t\t<td>账单时间</td>\r\n");
      out.write("\t\t\t</tr>\r\n");
      out.write("\t\t\t ");

	PageBean pb=(PageBean)request.getAttribute("pb");
	List tacts=pb.getData();
	for(int i=0;i<tacts.size();i++){
	AccountShow p=(AccountShow)tacts.get(i);
 
      out.write("\r\n");
      out.write("\t\t\t<tr>\r\n");
      out.write("    <td height=\"23\"><span class=\"STYLE1\">");
      out.print(p.getAccountId() );
      out.write("</span></td>\r\n");
      out.write("    <td><span class=\"STYLE1\"><a href=\"Ac?cmd=sc&s=");
      out.print(p.getAccountId()  );
      out.write("\" onclick=\"doit('mod',1)\">");
      out.print(p.getGoodsName() );
      out.write("</a></span></td>\r\n");
      out.write("\r\n");
      out.write("    <td><span class=\"STYLE1\">\r\n");
      out.write("    \t");
      out.print(p.getBusinessNum() );
      out.write("\r\n");
      out.write("    </span></td>\r\n");
      out.write("    <td><span class=\"STYLE1\">");
      out.print(p.getTotalPrice() );
      out.write("</span></td>\r\n");
      out.write("    <td><span class=\"STYLE1\">");
      out.print(p.getIsPayed() );
      out.write("</span></td>\r\n");
      out.write("    <td><span class=\"STYLE1\">");
      out.print(p.getProviderName() );
      out.write("</span></td>\r\n");
      out.write("      <td><span class=\"STYLE1\">");
      out.print(p.getGoodsIntro() );
      out.write("</span></td>\r\n");
      out.write("    <td><span class=\"STYLE1\">");
      out.print(p.getAccountDate() );
      out.write("</span></td>\r\n");
      out.write("  </tr>\r\n");
      out.write("  ");
}
      out.write("\r\n");
      out.write("\t\t</table>\r\n");
      out.write("\t\t<center>\r\n");
      out.write("共");
      out.print(pb.getCount());
      out.write("条记录，\r\n");
      out.write("第");
      out.print(pb.getP());
      out.write('页');
      out.write('/');
      out.write('共');
      out.print(pb.getPagetotal());
      out.write("页&nbsp;\r\n");
      out.write("<a href=\"Ac?cmd=all&p=1\">首页</a>\r\n");
      out.write("<a href=\"Ac?cmd=all&p=");
      out.print(pb.getP()-1);
      out.write("\">上一页</a>\r\n");
      out.write("<a href=\"Ac?cmd=all&p=");
      out.print(pb.getP()+1);
      out.write("\">下一页</a>\r\n");
      out.write("<a href=\"Ac?cmd=all&p=");
      out.print(pb.getPagetotal());
      out.write("\">尾页</a>&nbsp;\r\n");
      out.write("跳到第:\r\n");
      out.write("<select id=\"secpage\" onchange=toPage(this.value)>\r\n");
      out.write("\t<script language=\"javascript\">\r\n");
      out.write("\t\tfunction toPage(a){\r\n");
      out.write("\t\t\tlocation=\"Ac?cmd=all&p=\"+a;\r\n");
      out.write("\t\t}\r\n");
      out.write("\t\tfor(i=1;i<=");
      out.print(pb.getPagetotal());
      out.write(";i++){\r\n");
      out.write("\t\t\tdocument.write(\"<option value=\"+i+\">\"+i+\"</option>\");\r\n");
      out.write("\t\t}\r\n");
      out.write("\t\tdocument.getElementById(\"secpage\").value=");
      out.print(pb.getP());
      out.write("\r\n");
      out.write("\t</script>\r\n");
      out.write("</select>页\r\n");
      out.write("</center>\r\n");
      out.write("\t</div>\r\n");
      out.write("</div>\r\n");
      out.write("\r\n");
      out.write("  </body>\r\n");
      out.write("</html>\r\n");
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          try { out.clearBuffer(); } catch (java.io.IOException e) {}
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
