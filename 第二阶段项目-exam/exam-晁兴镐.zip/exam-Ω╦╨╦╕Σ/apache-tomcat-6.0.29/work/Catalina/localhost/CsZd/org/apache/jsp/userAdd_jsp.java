package org.apache.jsp;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import java.util.*;

public final class userAdd_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static final JspFactory _jspxFactory = JspFactory.getDefaultFactory();

  private static java.util.List _jspx_dependants;

  private javax.el.ExpressionFactory _el_expressionfactory;
  private org.apache.AnnotationProcessor _jsp_annotationprocessor;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspInit() {
    _el_expressionfactory = _jspxFactory.getJspApplicationContext(getServletConfig().getServletContext()).getExpressionFactory();
    _jsp_annotationprocessor = (org.apache.AnnotationProcessor) getServletConfig().getServletContext().getAttribute(org.apache.AnnotationProcessor.class.getName());
  }

  public void _jspDestroy() {
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      response.setContentType("text/html;charset=GBK");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write('\r');
      out.write('\n');

String path = request.getContextPath();
String basePath = request.getScheme()+"://"+request.getServerName()+":"+request.getServerPort()+path+"/";

      out.write("\r\n");
      out.write("\r\n");
      out.write("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">\r\n");
      out.write("<html>\r\n");
      out.write("  <head>\r\n");
      out.write("    <base href=\"");
      out.print(basePath);
      out.write("\">\r\n");
      out.write("    \r\n");
      out.write("    <title>My JSP 'userAdd.jsp' starting page</title>\r\n");
      out.write("    \r\n");
      out.write("\t<meta http-equiv=\"pragma\" content=\"no-cache\">\r\n");
      out.write("\t<meta http-equiv=\"cache-control\" content=\"no-cache\">\r\n");
      out.write("\t<meta http-equiv=\"expires\" content=\"0\">    \r\n");
      out.write("\t<meta http-equiv=\"keywords\" content=\"keyword1,keyword2,keyword3\">\r\n");
      out.write("\t<meta http-equiv=\"description\" content=\"This is my page\">\r\n");
      out.write("\t<!--\r\n");
      out.write("\t<link rel=\"stylesheet\" type=\"text/css\" href=\"styles.css\">\r\n");
      out.write("\t-->\r\n");
      out.write("<link type=\"text/css\" rel=\"stylesheet\" href=\"css/style.css\">\r\n");
      out.write("<script type=\"text/javascript\">\r\n");
      out.write("function checkit()\r\n");
      out.write("{\r\n");
      out.write("\t//判断是否是数字的正则表达式\r\n");
      out.write("\treturn true;\r\n");
      out.write("}\r\n");
      out.write("</script>\r\n");
      out.write("  </head>\r\n");
      out.write("  \r\n");
      out.write(" <body>\r\n");
      out.write("<div class=\"main\">\r\n");
      out.write("\t<div class=\"optitle clearfix\">\r\n");
      out.write("\t\t<div class=\"title\">用户管理&gt;&gt;</div>\r\n");
      out.write("\r\n");
      out.write("\t</div>\r\n");
      out.write("\t<form id=\"form1\" name=\"form1\" method=\"post\" action=\"Yh\" onsubmit=\"return checkit();\">\r\n");
      out.write("<input type=\"hidden\" name=\"cmd\" value=\"add\">\r\n");
      out.write("\t\t<div class=\"content\">\r\n");
      out.write("\t\t\t<table class=\"box\"><font color=\"red\"></font>\r\n");
      out.write("\t\t\t<tr>\r\n");
      out.write("\t\t\t\t\t<td class=\"field\">用户编号：</td>\r\n");
      out.write("\t\t\t\t\t<td><input type=\"text\" name=\"userId\" id=\"textfield\" class=\"text\"/> <font color=\"red\">*</font></td>\r\n");
      out.write("\r\n");
      out.write("\t\t\t\t</tr>\r\n");
      out.write("\t\t\t<tr>\r\n");
      out.write("\t\t\t\t\t<td class=\"field\">用户名称：</td>\r\n");
      out.write("\t\t\t\t\t<td><input type=\"text\" name=\"username\" class=\"text\" id=\"textfield2\" /> <font color=\"red\">*</font></td>\r\n");
      out.write("\t\t\t\t</tr>\r\n");
      out.write("\t\t\t\t<tr>\r\n");
      out.write("\t\t\t\t\t<td class=\"field\">用户密码：</td>\r\n");
      out.write("\r\n");
      out.write("\t\t\t\t\t<td><input type=\"password\" name=\"password\" class=\"text\" id=\"textfield2\" /> <font color=\"red\">*</font></td>\r\n");
      out.write("\t\t\t\t</tr>\r\n");
      out.write("\t\t\t<tr>\r\n");
      out.write("\t\t\t\t\t<td class=\"field\">确认密码：</td>\r\n");
      out.write("\t\t\t\t\t<td><input type=\"password\" name=\"password1\" class=\"text\"/> <font color=\"red\">*</font></td>\r\n");
      out.write("\t\t\t\t</tr>\r\n");
      out.write("\r\n");
      out.write("\t\t\t\t<tr>\r\n");
      out.write("\t\t\t\t\t<td class=\"field\">用户性别：</td>\r\n");
      out.write("\t\t\t\t\t<td><select name=\"sex\" id=\"select\">\r\n");
      out.write("    <option value=\"0\">女</option>\r\n");
      out.write("    <option value=\"1\">男</option>\r\n");
      out.write("  </select></td>\r\n");
      out.write("\t\t\t\t</tr>\r\n");
      out.write("\r\n");
      out.write("\t\t\t\t<tr>\r\n");
      out.write("\t\t\t\t\t<td class=\"field\">用户年龄：</td>\r\n");
      out.write("\t\t\t\t\t<td><input type=\"text\" name=\"age\" class=\"text\" id=\"textfield2\"/> <font color=\"red\">*</font></td>\r\n");
      out.write("\t\t\t\t</tr>\r\n");
      out.write("\t\t\t\t<tr>\r\n");
      out.write("\t\t\t\t\t<td class=\"field\">用户电话：</td>\r\n");
      out.write("\t\t\t\t\t<td><input type=\"text\" name=\"mobile\" class=\"text\" id=\"textfield2\"/> <font color=\"red\">*</font></td>\r\n");
      out.write("\r\n");
      out.write("\t\t\t\t</tr>\r\n");
      out.write("\t\t\t\t<tr>\r\n");
      out.write("\t\t\t\t\t<td class=\"field\">用户地址：</td>\r\n");
      out.write("\t\t\t\t\t<td><textarea name=\"address\" id=\"textarea\" class=\"text\" cols=\"45\" rows=\"5\"></textarea></td>\r\n");
      out.write("\t\t\t\t</tr>\r\n");
      out.write("\t\t\t\t<tr>\r\n");
      out.write("\t\t\t\t\t<td class=\"field\">用户权限：</td>\r\n");
      out.write("\r\n");
      out.write("\t\t\t\t\t<td><input type=\"radio\" name=\"auth\" id=\"auth\" value=\"0\" checked=\"checked\"/>普通用户\r\n");
      out.write("\t\t\t\t\t<input type=\"radio\" name=\"auth\" id=\"auth\" value=\"1\" />经理</td>\r\n");
      out.write("\t\t\t\t</tr>\r\n");
      out.write("\t\t\t</table>\r\n");
      out.write("\t\t</div>\r\n");
      out.write("\t\t<div class=\"buttons\">\r\n");
      out.write("\t\t\t<input type=\"submit\" name=\"button\" id=\"button\" value=\"数据提交\" class=\"input-button\"/>\r\n");
      out.write("\t\t\t  <input type=\"button\" name=\"button\" id=\"button\" onclick=\"history.back()\" value=\"返回\" class=\"input-button\"/> \r\n");
      out.write("\t\t</div>\r\n");
      out.write("\r\n");
      out.write("\t</form>\r\n");
      out.write("</div>\r\n");
      out.write("</body>\r\n");
      out.write("</html>\r\n");
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          try { out.clearBuffer(); } catch (java.io.IOException e) {}
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
