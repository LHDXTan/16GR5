package com.wb.actions;


import java.util.List;
import org.apache.struts2.ServletActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.wb.beans.Adminuser;
import com.wb.beans.Login;
import com.wb.beans.Student;
import com.wb.beans.Teacher;
import com.wb.dao.BaseDaoImpl;

public class LoginAction extends ActionSupport {
    private Adminuser adminuser;
    private Student student;
    private Teacher teacher;
    private Login user;
    private int role;
    BaseDaoImpl bd=new BaseDaoImpl();
	
    
    
    public String login(){
	
    if(user.getName()==""){
    	ServletActionContext.getRequest().setAttribute("sp","账号不能为空");
		return"login";
	}else if(user.getPwd()==""){
		ServletActionContext.getRequest().setAttribute("sp","密码不能为空");
		return"login";
	}	
		
		
	if(role==1){
		String name=user.getName();
	 List <Adminuser>list=bd.denglu(name,role);
	     
		if(list.size()==0){
			ServletActionContext.getRequest().setAttribute("sp","账号不存在");
			return "login";
	}else if(user.getPwd().equals(list.get(0).getPassword())){
		 ServletActionContext.getRequest().getSession().setAttribute("role", role);
		 ServletActionContext.getRequest().getSession().setAttribute("name", user.getName());   
		    return"index";	
	}else{
		ServletActionContext.getRequest().setAttribute("sp","密码不正确");
		return "login" ;
	}
	}else if(role==2){
		String name=user.getName();
		 List <Teacher>list=bd.denglu(name,role);
		 if(list.size()==0){
			 ServletActionContext.getRequest().setAttribute("sp","账号不存在");
				return "login";
		}else if(user.getPwd().equals(list.get(0).getPassword())){
			 ServletActionContext.getRequest().getSession().setAttribute("role", role);
			 ServletActionContext.getRequest().getSession().setAttribute("name", user.getName()); 
				return "index" ;
		}else{
			ServletActionContext.getRequest().setAttribute("sp","密码不正确");
			    return"login";	
		}
	}else if(role==3){
		String name=user.getName();
		 List <Student>list=bd.denglu(name,role);
		 if(list.size()==0){
			 ServletActionContext.getRequest().setAttribute("sp","账号不存在");
				return "login";
		}else if(user.getPwd().equals(list.get(0).getPassword())){
			 ServletActionContext.getRequest().getSession().setAttribute("role", role);
			 ServletActionContext.getRequest().getSession().setAttribute("name", user.getName()); 
				return "index" ;
		}else{
			ServletActionContext.getRequest().setAttribute("sp","密码不正确");
			    return"login";	
		}
	}
		return null;
	}

	public int getRole() {
		return role;
	}

	public void setRole(int role) {
		this.role = role;
	}


	public Adminuser getAdminuser() {
		return adminuser;
	}

	public void setAdminuser(Adminuser adminuser) {
		this.adminuser = adminuser;
	}

	public Student getStudent() {
		return student;
	}

	public void setStudent(Student student) {
		this.student = student;
	}

	public Teacher getTeacher() {
		return teacher;
	}

	public void setTeacher(Teacher teacher) {
		this.teacher = teacher;
	}

	public Login getUser() {
		return user;
	}

	public void setUser(Login user) {
		this.user = user;
	}
	
	
	
}
