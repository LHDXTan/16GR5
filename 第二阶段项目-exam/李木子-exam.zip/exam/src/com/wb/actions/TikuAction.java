package com.wb.actions;

import java.util.List;

import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ActionSupport;
import com.wb.dao.BaseDaoImpl;

public class TikuAction extends ActionSupport {
  private int suid;
  private String s1;
  private String s2;
	  BaseDaoImpl bd =new BaseDaoImpl();
	 public String  select(){
		 String sql2="select  distinct sustage from subject";
		 String sql1="select  distinct sudirec from subject ";
		 String sql="select su.suId,su.suName,su.sudirec,su.sustage, (CASE WHEN num1 IS null then '0' else num1 end) as num1,(CASE WHEN num2 IS null then '0' else num2 end) as num2 from (select tab1.suid,tab1.num num1,tab2.num num2 from(select count(pType)num,suid from question where pType='机试'  group by suid)as tab1 FULL  JOIN(select count(pType)num,suid  from question where pType='笔试'  group by suid)as tab2 on tab1.suid=tab2.suid)as tab3 right join subject su on su.suId=tab3.suid";
		   List list=bd.getsql(sql);
		   List list1=bd.getsql(sql1);
		   List<Object[]>list2=bd.getsql(sql2);
		   ServletActionContext.getRequest().getSession().setAttribute("alist", list);
		   ServletActionContext.getRequest().getSession().setAttribute("alist1", list1);
		   ServletActionContext.getRequest().getSession().setAttribute("alist2", list2);
//		 for( Object[] o:list1){
//			 System.out.println(o[0]);
//			 
//		 }
		   
		   
		 return "tiku"; 
	 } 
	public String select1(){
	 	 String sql="select * from question where suid="+suid+" and pType='机试'";
		 List<Object[]>list=bd.getsql(sql);
		 ServletActionContext.getRequest().getSession().setAttribute("lis", list);
		 return "tklb";
	
	}
	public String select2(){	
		 String sql="select * from question where suid="+suid+" and pType='笔试'";
		 List<Object[]>list=bd.getsql(sql);
		 ServletActionContext.getRequest().getSession().setAttribute("lis", list);
		 return "tklb";

	}
	public String select3(){
		List list=bd.tikuchaxun(s1,s2);
		ServletActionContext.getRequest().getSession().setAttribute("alist", list);
		
		return "tiku";
	}
	
	public String insert(){
		
		
		return null;
	
	}
	
	public int getSuid() {
		return suid;
	}
	public void setSuid(int suid) {
		this.suid = suid;
	}
	public String getS1() {
		return s1;
	}
	public void setS1(String s1) {
		this.s1 = s1;
	}
	public String getS2() {
		return s2;
	}
	public void setS2(String s2) {
		this.s2 = s2;
	}

	
}
