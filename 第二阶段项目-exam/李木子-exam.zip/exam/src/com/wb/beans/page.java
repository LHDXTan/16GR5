package com.wb.beans;

import java.util.ArrayList;
import java.util.List;

public class page {
	private int pagesize;
	private int total;
	private int totalpage;
	private int p;
	private List list;
	
	public page(){
		pagesize = 5;
		p = 1;
		list = new ArrayList();
	}

	public int getPagesize() {
		return pagesize;
	}

	public void setPagesize(int pagesize) {
		this.pagesize = 5;
	}

	public int getTotal() {
		return total;
	}

	public void setTotal(int total) {
		this.total = total;
		this.totalpage = (total+this.pagesize-1)/pagesize;
	}

	public int getTotalpage() {
		return totalpage;
	}

	public void setTotalpage(int totalpage) {
		this.totalpage = totalpage;
	}

	public int getP() {
		return p;
	}

	public void setP(int p) {
		if(p<1){
			p=1;
		}else if(p>=pagesize){
			p = pagesize;
		}else{
			this.p = p;
		}
	}

	public List getList() {
		return list;
	}

	public void setList(List list) {
		this.list = list;
	}
	
	
}
