package com.wb.dao;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.wb.basedao.HibernateSessionFactory;
import com.wb.beans.Adminuser;
import com.wb.beans.Teacher;


public class BaseDaoImpl  implements IBaseDao{

	@Override
	public void add(Object obj) {
		Session  session = HibernateSessionFactory.getSession();
		Transaction tx = session.beginTransaction();
		try{
			session.save(obj);
			tx.commit();
		}catch(Exception e){
			tx.rollback();
			e.printStackTrace();
		}
		
		HibernateSessionFactory.closeSession();
	} 

	@Override
	public void delete(Object obj) {
		Session  session = HibernateSessionFactory.getSession();
		Transaction tx = session.beginTransaction();
		try{
			session.delete(obj);
			tx.commit();
		}catch(Exception e){
			tx.rollback();
			e.printStackTrace();
		}
		
		HibernateSessionFactory.closeSession();	}

	@Override
	public Object getObjectById(Class clazz, Serializable id) {
		Session  session = HibernateSessionFactory.getSession();
		Transaction tx = session.beginTransaction();
		Object obj = null;
		try{
			obj = session.get(clazz, id);
			tx.commit();
		}catch(Exception e){
			tx.rollback();
			e.printStackTrace();
		}
		
		HibernateSessionFactory.closeSession();
		return obj;
	}

	@Override
	public List getObjects(String hql) {
		Session  session = HibernateSessionFactory.getSession();
		Transaction tx = session.beginTransaction();
		List result = new ArrayList();
		try{
			result = session.createQuery(hql).list();
			tx.commit();
		}catch(Exception e){
			tx.rollback();
			e.printStackTrace();
		}
		
		HibernateSessionFactory.closeSession();
		return result;
	}

	@Override
	public void update(Object obj) {
		Session  session = HibernateSessionFactory.getSession();
		Transaction tx = session.beginTransaction();
		try{
			session.update(obj);
			tx.commit();
		}catch(Exception e){
			tx.rollback();
			e.printStackTrace();
		}
		
		HibernateSessionFactory.closeSession();
	}

	
	
	public List denglu(String name,int role){
		List list=new ArrayList();
		 Query query=null;
		String hql1="select a from Adminuser a where a.loginuser=?";
		String hql2="select a from Teacher a where a.loginuser=?";
		String hql3="select a from Student a where a.loginuser=?";
		Session  session = HibernateSessionFactory.getSession();
		if(role==1){
         query=session.createQuery(hql1);
		}else if(role==2){
		 query=session.createQuery(hql2);
		}else if(role==3){
		 query=session.createQuery(hql3);
			}
		
		query.setString(0,name);
		
		list =query.list();
		return list;	
	}
	public List getsql(String sql) {
		Session  session = HibernateSessionFactory.getSession();
		Transaction tx = session.beginTransaction();
		List result = new ArrayList();
		try{
			result = session.createSQLQuery(sql).list();
			tx.commit();
		}catch(Exception e){
			tx.rollback();
			e.printStackTrace();
		}
		
		HibernateSessionFactory.closeSession();
		return result;
	}
	public List tikuchaxun(String ss1,String ss2){
		List list=new ArrayList();
		 SQLQuery query=null;
		 System.out.println(ss1);
		String sql="select  su.suId ID,su.suName , su.sudirec ,su.sustage,(CASE WHEN num1 IS null then '0' else num1 end) as num1,(CASE WHEN num2 IS null then '0' else num2 end) as num2 from (select tab1.suid,tab1.num num1,tab2.num num2 from(select count(ptype)num,suid  from question where ptype='机试'  group by suid)as tab1 FULL  JOIN(select count(ptype)num,suid  from question where ptype='笔试'  group by suid)as tab2 on tab1.suid=tab2.suid)as tab3 right join (select * from subject   where sudirec=? and sustage=?) su on su.suId=tab3.suid";
		Session  session = HibernateSessionFactory.getSession();
		 query=session.createSQLQuery(sql);
		
		query.setString(0,ss1);
		query.setString(1,ss2);
		list =query.list();
		return list;	
	}
	
	
	
}
