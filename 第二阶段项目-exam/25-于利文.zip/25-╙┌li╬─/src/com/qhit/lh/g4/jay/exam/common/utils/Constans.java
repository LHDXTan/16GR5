/**
 * 
 */
package com.qhit.lh.g4.jay.exam.common.utils;

/**
 * @author admin
 * 2017年12月29日
 */
public class Constans {
	public static final String VIEW_LOGIN = "login_view";

}
